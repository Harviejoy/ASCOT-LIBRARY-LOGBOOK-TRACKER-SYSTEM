/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

package allts.caps;

import com.github.sarxos.webcam.Webcam;
import com.github.sarxos.webcam.WebcamPanel;
import com.github.sarxos.webcam.WebcamResolution;
import java.awt.FlowLayout;
import java.io.ByteArrayOutputStream;
import java.sql.*;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.Dimension;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.JTableHeader;

import java.awt.*;

import com.google.zxing.*;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.HybridBinarizer;
import com.google.zxing.qrcode.QRCodeWriter;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.File;

import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import javax.swing.table.DefaultTableModel;

import java.util.Date;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

import java.util.List;
import java.util.ArrayList;

import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.FileOutputStream;
import javax.swing.table.TableModel;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;



/**
 *
 * @author Acer
 */
public class dashboard extends javax.swing.JFrame implements Runnable, ThreadFactory{

      private Webcam webcam = null;
    private WebcamPanel panel = null;
    private int userId;
    private Executor executor = Executors.newSingleThreadExecutor(this);
    
    Color DefaultColor = new Color(255,128,0);
          Color DefaultColorExit   = new Color(255,153,51);
    
    Connection conn;
   
    
    public dashboard( int userId) {
        initComponents();
        this.userId = userId;
        id12.hide();
        stat.hide();
        idd.hide();
//        idd1.hide();
        scan.setVisible(false);
        
          
        
        // Hide the tab headers
        jTabbedPane1.setUI(new javax.swing.plaf.basic.BasicTabbedPaneUI() {
            @Override
            protected int calculateTabAreaHeight(int tabPlacement, int horizRunCount, int maxTabHeight) {
                return 0;
            }
        });
        
         try {
            // Replace with your DB settings
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/logbook_db?zeroDateTimeBehavior=CONVERT_TO_NULL", "root", "");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
         
         
         
         lnametxt.setColumns(15); 
         cnumbertxt.setColumns(15); 
         gnumbertxt.setColumns(15); 
         mnametxt.setColumns(15); 
         snumbertxt.setColumns(15); 
//        coursetxt.setPrototypeDisplayValue("XXXXXXXXXXXXXXX");
//        yeartxt.setPrototypeDisplayValue("XXXXXXXXXXXXXXX");
         
         fetchData(jTable1); 
         
        Font headerFont = new Font("Arial", Font.BOLD, 15);  // Customize font for header
        Font font = new Font("Arial", Font.PLAIN, 14);
        JTableHeader header = jTable1.getTableHeader();
        header.setFont(headerFont);

        jTable1.setFont(font);
        jTable1.setRowHeight(30); 
        jTable3.setFont(font);
        jTable3.setRowHeight(30); 
        
        Font headerFont4 = new Font("Arial", Font.BOLD, 15);  // Customize font for header
        Font font4 = new Font("Arial", Font.PLAIN, 14);
        JTableHeader header4 = jTable5.getTableHeader();
        header4.setFont(headerFont4);

        jTable5.setFont(font4);
        jTable5.setRowHeight(30);  
        
        Font headerFont3 = new Font("Arial", Font.BOLD, 15);
        JTableHeader header3 = jTable3.getTableHeader();
        header3.setFont(headerFont3);
        
        
        Font headerFont6 = new Font("Arial", Font.BOLD, 15);  // Customize font for header
        Font font6 = new Font("Arial", Font.PLAIN, 14);
        JTableHeader header6 = jTable6.getTableHeader();
        header6.setFont(headerFont6);

        jTable6.setFont(font6);
        jTable6.setRowHeight(30); 
        
        jTable1.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {  // To prevent double triggering
                    int selectedRow = jTable1.getSelectedRow();
                    
                    if (selectedRow != -1) {
                        // Retrieve data from the selected row (only the visible columns)
                        String id = jTable1.getValueAt(selectedRow, 0).toString();
                        String student_id = jTable1.getValueAt(selectedRow, 2).toString(); // Student ID (column 0)
                        String firstName = jTable1.getValueAt(selectedRow, 4).toString(); // First Name (column 1)
                        String lastName = jTable1.getValueAt(selectedRow, 3).toString(); // Last Name (column 2)
                        String middleName = jTable1.getValueAt(selectedRow, 5).toString(); // Middle Name (column 3)
                        String course = jTable1.getValueAt(selectedRow, 6).toString(); // Course (column 4)
                        String year = jTable1.getValueAt(selectedRow, 7).toString(); // Course (column 4)

                        // Display in the JTextFields
                        id12.setText(id);
                        snumbertxt.setText(student_id);
                        fnametxt.setText(firstName);
                        lnametxt.setText(lastName);
                        mnametxt.setText(middleName);
                        coursetxt.setSelectedItem(course);
                        yeartxt.setSelectedItem(year);
                        
                        // Fetch the extra data from the database (address, c_number, g_number)
                        fetchAdditionalData(student_id); // Pass student_id to fetch extra data
                        generateqr();
                        snumbertxt.setEnabled(false);
                    }
                }
            }
        });
        
                
        jTable2.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {  // To prevent double triggering
                    int selectedRow = jTable2.getSelectedRow();
                    
                    if (selectedRow != -1) {
                        // Retrieve data from the selected row (only the visible columns)
                        String student_id = jTable2.getValueAt(selectedRow, 0).toString();

                        // Display in the JTextFields
                        sid.setText(student_id);
                        
                        // Fetch the extra data from the database (address, c_number, g_number)
                        fetchAdditionalData(student_id); // Pass student_id to fetch extra data
                        generateqr();
                        snumbertxt.setEnabled(false);
                    }
                }
            }
        });
        
         jTable2.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {  // To prevent double triggering
                    int selectedRow = jTable2.getSelectedRow();
                    
                    if (selectedRow != -1) {
                        // Retrieve data from the selected row (only the visible columns)
                        String student_id = jTable2.getValueAt(selectedRow, 0).toString();

                        // Display in the JTextFields
                        isd2.setText(student_id);
                        
                        // Fetch the extra data from the database (address, c_number, g_number)
                        fetchAdditionalData(student_id); // Pass student_id to fetch extra data
                        generateqr();
                        snumbertxt.setEnabled(false);
                    }
                }
            }
        });
        
         jTable2.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {  // To prevent double triggering
                    int selectedRow = jTable2.getSelectedRow();
                    
                    if (selectedRow != -1) {
                        // Retrieve data from the selected row (only the visible columns)
                        String student_id = jTable2.getValueAt(selectedRow, 0).toString();

                        // Display in the JTextFields
                        sid.setText(student_id);
                        
                        // Fetch the extra data from the database (address, c_number, g_number)
                        fetchAdditionalData(student_id); // Pass student_id to fetch extra data
                        generateqr();
                        snumbertxt.setEnabled(false);
                    }
                }
            }
        });
        
        jTable5.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                int selectedRow = jTable5.getSelectedRow();

                if (selectedRow != -1) { // Ensure a row is selected
                    // Get the model index in case the table is sorted
                    int modelRow = jTable5.convertRowIndexToModel(selectedRow);

                    // Assuming 'id' is in column index 0
                    Object idValue = jTable5.getModel().getValueAt(modelRow, 0);

                    // Convert to int if needed
                    int id = Integer.parseInt(idValue.toString());
                  
                    idd1.setText(String.valueOf(id));
                    
                    System.out.println("Selected ID: " + id);
                }
            }
        });
        
        jTabbedPane1.setSelectedIndex(1);
        
        jTable4.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                int selectedRow = jTable4.getSelectedRow();

                if (selectedRow != -1) { // Ensure a row is selected
                    // Get the model index in case the table is sorted
                    int modelRow = jTable4.convertRowIndexToModel(selectedRow);

                    // Assuming 'id' is in column index 0
                    Object idValue = jTable4.getModel().getValueAt(modelRow, 0);

                    // Convert to int if needed
                    int id = Integer.parseInt(idValue.toString());
                  
                    sid1.setText(String.valueOf(id));
                    
                    idddd.setText(String.valueOf(id));
                    System.out.println("Selected ID: " + id);
                }
            }
        });
        
        
        jTable5.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {  // To prevent double triggering
                    int selectedRow = jTable5.getSelectedRow();
                    
                    if (selectedRow != -1) {
                        // Retrieve data from the selected row (only the visible columns)
                        String iddd = jTable5.getValueAt(selectedRow, 0).toString();
                        String purp = jTable5.getValueAt(selectedRow, 7).toString();
                        String b_name = jTable5.getValueAt(selectedRow, 8).toString();
                        String authtor = jTable5.getValueAt(selectedRow, 9).toString(); 
                        String b_num = jTable5.getValueAt(selectedRow, 10).toString();

                        // Display in the JTextFields
                        purposecb.setSelectedItem(purp);
                        booktitle.setText(b_name);
                        author.setText(authtor);
                        booknum.setText(b_num);
                         int id = Integer.parseInt(iddd.toString());
                         myid.setText(String.valueOf(id));
                        
                    }
                }
            }
        });
        
        jTable6.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                int selectedRow = jTable6.getSelectedRow();

                if (selectedRow != -1) { // Ensure a row is selected
                    // Get the model index in case the table is sorted
                    int modelRow = jTable6.convertRowIndexToModel(selectedRow);

                    // Assuming 'id' is in column index 0
                    Object idValue = jTable6.getModel().getValueAt(modelRow, 0);

                    // Convert to int if needed
                    int id = Integer.parseInt(idValue.toString());
                  
                    sid2.setText(String.valueOf(id));
                    id10.setText(String.valueOf(id));
                    System.out.println("Selected ID: " + id);
                }
            }
        });
        
        
        
        
        
        
        jTable3.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                int selectedRow = jTable3.getSelectedRow();

                if (selectedRow != -1) { // Ensure a row is selected
                    // Get the model index in case the table is sorted
                    int modelRow = jTable3.convertRowIndexToModel(selectedRow);

                    // Assuming 'id' is in column index 0
                    Object idValue = jTable3.getModel().getValueAt(modelRow, 0);

                    // Convert to int if needed
                    int id = Integer.parseInt(idValue.toString());
                  
                    idd1.setText(String.valueOf(id));
                    
                    System.out.println("Selected ID: " + id);
                }
            }
        });
        
        sid.setVisible(false);

        
        snumbertxt.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) {
                fetchStatus();
            }
            public void removeUpdate(DocumentEvent e) {
                fetchStatus();
            }
            public void insertUpdate(DocumentEvent e) {
                fetchStatus();
            }

            public void fetchStatus() {
                String studentId = snumbertxt.getText().trim();

                String url = "jdbc:mysql://localhost:3306/logbook_db?zeroDateTimeBehavior=CONVERT_TO_NULL";
                String username = "root";
                String password = "";

                String sql = "SELECT status, id FROM loggbook WHERE student_id = ?";

                try (Connection conn = DriverManager.getConnection(url, username, password);
                     PreparedStatement stmt = conn.prepareStatement(sql)) {

                    stmt.setString(1, studentId);

                    try (ResultSet rs = stmt.executeQuery()) {
                        if (rs.next()) {
                            int status = rs.getInt("status");
                            int myid = rs.getInt("id");
                            
                            stat.setText(String.valueOf(status));
                            idd.setText(String.valueOf(myid));
                        } else {
                            stat.setText("Not Found");
                        }
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Database error occurred.");
                }
            }
        });
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel12 = new javax.swing.JPanel();
        usernametxt4 = new javax.swing.JLabel();
        jScrollPane8 = new javax.swing.JScrollPane();
        jTable7 = new javax.swing.JTable();
        jPanel13 = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        lnametxt = new javax.swing.JTextField();
        fnametxt = new javax.swing.JTextField();
        mnametxt = new javax.swing.JTextField();
        snumbertxt = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        gnumbertxt = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        cnumbertxt = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        addresstxt = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        qrtxt = new javax.swing.JPanel();
        coursetxt = new javax.swing.JComboBox<>();
        yeartxt = new javax.swing.JComboBox<>();
        jLabel18 = new javax.swing.JLabel();
        idd = new javax.swing.JLabel();
        stat = new javax.swing.JTextField();
        idd1 = new javax.swing.JLabel();
        id12 = new javax.swing.JTextField();
        jPanel16 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel17 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jButton25 = new javax.swing.JButton();
        jPanel18 = new javax.swing.JPanel();
        searchtxt1 = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jButton10 = new javax.swing.JButton();
        courselb1 = new javax.swing.JComboBox<>();
        jLabel14 = new javax.swing.JLabel();
        fromDateChooser1 = new com.toedter.calendar.JDateChooser();
        jLabel21 = new javax.swing.JLabel();
        toDateChoose1 = new com.toedter.calendar.JDateChooser();
        jLabel22 = new javax.swing.JLabel();
        jPanel14 = new javax.swing.JPanel();
        jPanel33 = new javax.swing.JPanel();
        jPanel34 = new javax.swing.JPanel();
        lnametxt2 = new javax.swing.JTextField();
        qrtxt4 = new javax.swing.JPanel();
        scan = new javax.swing.JButton();
        jLabel30 = new javax.swing.JLabel();
        booktitle = new javax.swing.JTextField();
        jLabel35 = new javax.swing.JLabel();
        author = new javax.swing.JTextField();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        booknum = new javax.swing.JTextField();
        purposecb = new javax.swing.JComboBox<>();
        test = new javax.swing.JTextField();
        myid = new javax.swing.JTextField();
        testing = new javax.swing.JTextField();
        jPanel35 = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTable5 = new javax.swing.JTable();
        jPanel36 = new javax.swing.JPanel();
        jButton24 = new javax.swing.JButton();
        jButton26 = new javax.swing.JButton();
        jButton27 = new javax.swing.JButton();
        jButton28 = new javax.swing.JButton();
        jButton29 = new javax.swing.JButton();
        jButton23 = new javax.swing.JButton();
        jButton33 = new javax.swing.JButton();
        jPanel37 = new javax.swing.JPanel();
        searchtxt2 = new javax.swing.JTextField();
        jLabel31 = new javax.swing.JLabel();
        jButton30 = new javax.swing.JButton();
        courselb3 = new javax.swing.JComboBox<>();
        jLabel32 = new javax.swing.JLabel();
        toDateChooser1 = new com.toedter.calendar.JDateChooser();
        jLabel33 = new javax.swing.JLabel();
        fromDateChooser2 = new com.toedter.calendar.JDateChooser();
        jLabel34 = new javax.swing.JLabel();
        jPanel23 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jPanel24 = new javax.swing.JPanel();
        jButton12 = new javax.swing.JButton();
        jButton34 = new javax.swing.JButton();
        search = new javax.swing.JTextField();
        jButton13 = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        sid = new javax.swing.JLabel();
        isd2 = new javax.swing.JLabel();
        jPanel25 = new javax.swing.JPanel();
        jPanel26 = new javax.swing.JPanel();
        jPanel27 = new javax.swing.JPanel();
        lnametxt1 = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        qrtxt3 = new javax.swing.JPanel();
        jLabel27 = new javax.swing.JLabel();
        purposetxt = new javax.swing.JTextField();
        jPanel28 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jPanel29 = new javax.swing.JPanel();
        jButton16 = new javax.swing.JButton();
        jButton18 = new javax.swing.JButton();
        jButton17 = new javax.swing.JButton();
        jButton21 = new javax.swing.JButton();
        jButton22 = new javax.swing.JButton();
        jButton20 = new javax.swing.JButton();
        jPanel30 = new javax.swing.JPanel();
        searchtxt = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        jButton19 = new javax.swing.JButton();
        courselb2 = new javax.swing.JComboBox<>();
        jLabel29 = new javax.swing.JLabel();
        toDateChooser = new com.toedter.calendar.JDateChooser();
        jLabel23 = new javax.swing.JLabel();
        fromDateChooser = new com.toedter.calendar.JDateChooser();
        jLabel25 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel31 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTable4 = new javax.swing.JTable();
        jPanel32 = new javax.swing.JPanel();
        jButton14 = new javax.swing.JButton();
        jButton35 = new javax.swing.JButton();
        search3 = new javax.swing.JTextField();
        jButton15 = new javax.swing.JButton();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        sid1 = new javax.swing.JLabel();
        idddd = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jPanel38 = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        jTable6 = new javax.swing.JTable();
        jPanel39 = new javax.swing.JPanel();
        jButton31 = new javax.swing.JButton();
        jButton36 = new javax.swing.JButton();
        search1 = new javax.swing.JTextField();
        jButton32 = new javax.swing.JButton();
        jLabel38 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        sid2 = new javax.swing.JLabel();
        id10 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        usernametxt2 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        usernametxt8 = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        usernametxt = new javax.swing.JLabel();
        icon = new javax.swing.JLabel();
        icon1 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jPanel21 = new javax.swing.JPanel();
        usernametxt3 = new javax.swing.JLabel();
        jPanel22 = new javax.swing.JPanel();
        usernametxt9 = new javax.swing.JLabel();
        jPanel40 = new javax.swing.JPanel();
        usernametxt10 = new javax.swing.JLabel();

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel2.setBackground(new java.awt.Color(255, 231, 81));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel2.setText("ASCOT LIBRARY LOGBOOK");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setText("TRACKER SYSTEM");

        jLabel26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/allts/caps/Adobe-Express-file.png"))); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel26)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel26))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel3)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));

        usernametxt4.setFont(new java.awt.Font("Microsoft Sans Serif", 1, 20)); // NOI18N
        usernametxt4.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        usernametxt4.setText("Log Activity");
        usernametxt4.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));

        jTable7.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable7.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTable7KeyPressed(evt);
            }
        });
        jScrollPane8.setViewportView(jTable7);

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane8, javax.swing.GroupLayout.DEFAULT_SIZE, 1500, Short.MAX_VALUE)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addComponent(usernametxt4)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(usernametxt4, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.DEFAULT_SIZE, 776, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab1", jPanel12);

        jPanel15.setBackground(new java.awt.Color(255, 231, 81));
        jPanel15.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel4.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel4.setText("Last Name");

        jLabel5.setFont(new java.awt.Font("Microsoft Sans Serif", 1, 24)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Enter Information");

        jLabel6.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel6.setText("First Name");

        jLabel7.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel7.setText("Middle Name");

        lnametxt.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        lnametxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lnametxtActionPerformed(evt);
            }
        });
        lnametxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                lnametxtKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                lnametxtKeyReleased(evt);
            }
        });

        fnametxt.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        fnametxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                fnametxtKeyPressed(evt);
            }
        });

        mnametxt.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        mnametxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnametxtActionPerformed(evt);
            }
        });
        mnametxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                mnametxtKeyPressed(evt);
            }
        });

        snumbertxt.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        snumbertxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                snumbertxtKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                snumbertxtKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                snumbertxtKeyTyped(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel8.setText("Library Card Number");

        jLabel9.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel9.setText("Course");

        gnumbertxt.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        gnumbertxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                gnumbertxtKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                gnumbertxtKeyTyped(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel10.setText("Guardian's Number");

        cnumbertxt.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        cnumbertxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cnumbertxtActionPerformed(evt);
            }
        });
        cnumbertxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                cnumbertxtKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                cnumbertxtKeyTyped(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel11.setText("Contact Number");

        addresstxt.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        addresstxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                addresstxtKeyPressed(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel12.setText("Address");

        jLabel15.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel15.setText("QR Code");

        javax.swing.GroupLayout qrtxtLayout = new javax.swing.GroupLayout(qrtxt);
        qrtxt.setLayout(qrtxtLayout);
        qrtxtLayout.setHorizontalGroup(
            qrtxtLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 197, Short.MAX_VALUE)
        );
        qrtxtLayout.setVerticalGroup(
            qrtxtLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 164, Short.MAX_VALUE)
        );

        coursetxt.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select", "BSIT", "BSA", "BSED", "BSHM", "BIT", "BSCE" }));
        coursetxt.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                coursetxtItemStateChanged(evt);
            }
        });

        yeartxt.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select", "Male", "Female" }));
        yeartxt.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                yeartxtItemStateChanged(evt);
            }
        });

        jLabel18.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel18.setText("Gender");

        idd.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        idd.setText("     ");

        stat.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        stat.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                statKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                statKeyTyped(evt);
            }
        });

        idd1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        idd1.setText("     ");

        id12.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        id12.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                id12KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                id12KeyTyped(evt);
            }
        });

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel8)
                            .addComponent(jLabel7)
                            .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.LEADING))
                            .addComponent(jLabel9))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(fnametxt)
                            .addComponent(mnametxt)
                            .addComponent(snumbertxt)
                            .addComponent(lnametxt)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
                                .addComponent(coursetxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(yeartxt, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
                            .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel12, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.TRAILING))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(gnumbertxt)
                                .addComponent(cnumbertxt)
                                .addComponent(addresstxt, javax.swing.GroupLayout.DEFAULT_SIZE, 220, Short.MAX_VALUE)))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
                            .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel15Layout.createSequentialGroup()
                                    .addComponent(idd1, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 41, Short.MAX_VALUE)
                                    .addComponent(jLabel15))
                                .addGroup(jPanel15Layout.createSequentialGroup()
                                    .addComponent(idd, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(stat, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel15Layout.createSequentialGroup()
                                    .addGap(0, 0, Short.MAX_VALUE)
                                    .addComponent(id12, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 25, Short.MAX_VALUE)
                            .addComponent(qrtxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(10, 10, 10))))
                .addGap(14, 14, 14))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(jLabel5)
                .addGap(18, 18, 18)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(lnametxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(fnametxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(mnametxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(snumbertxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(coursetxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(yeartxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel18))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(addresstxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12))
                .addGap(9, 9, 9)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(cnumbertxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(gnumbertxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGap(51, 51, 51)
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(stat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(idd))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel15)
                            .addComponent(idd1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(id12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(qrtxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(71, 71, 71))
        );

        jPanel16.setBackground(new java.awt.Color(255, 255, 255));
        jPanel16.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTable1KeyPressed(evt);
            }
        });
        jScrollPane2.setViewportView(jTable1);

        jPanel17.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jButton2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jButton2.setText("Update");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton7.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jButton7.setText("Add");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jButton8.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jButton8.setText("Delete");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jButton9.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jButton9.setText("Clear");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        jButton11.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jButton11.setText("Recycle Bin");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        jButton25.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jButton25.setText("Save QR Code");
        jButton25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton25ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel17Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton25)
                .addGap(18, 18, 18)
                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton25, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        searchtxt1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 14)); // NOI18N
        searchtxt1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchtxt1ActionPerformed(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel13.setText("Search");

        jButton10.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 14)); // NOI18N
        jButton10.setText("Search");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        courselb1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select", "BSIT", "BSA", "BSED", "BSHM", "BIT", "BSCE" }));

        jLabel14.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel14.setText("Filter by course");

        jLabel21.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel21.setText("From:");

        jLabel22.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel22.setText("To:");

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(courselb1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 50, Short.MAX_VALUE)
                .addComponent(jLabel21)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(fromDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel22)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(toDateChoose1, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel13)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(searchtxt1, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(17, 17, 17))
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(toDateChoose1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel22)
                    .addComponent(fromDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(searchtxt1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel13)
                        .addComponent(jButton10)
                        .addComponent(courselb1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel14)
                        .addComponent(jLabel21)))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel16Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel18, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane2))
                .addContainerGap())
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel16Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, 412, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        jTabbedPane1.addTab("tab2", jPanel13);

        jPanel34.setBackground(new java.awt.Color(255, 231, 81));
        jPanel34.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        lnametxt2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        lnametxt2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                lnametxt2KeyPressed(evt);
            }
        });

        scan.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        scan.setText("Scan Again");
        scan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                scanActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout qrtxt4Layout = new javax.swing.GroupLayout(qrtxt4);
        qrtxt4.setLayout(qrtxt4Layout);
        qrtxt4Layout.setHorizontalGroup(
            qrtxt4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
            .addGroup(qrtxt4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(qrtxt4Layout.createSequentialGroup()
                    .addGap(147, 147, 147)
                    .addComponent(scan, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(148, Short.MAX_VALUE)))
        );
        qrtxt4Layout.setVerticalGroup(
            qrtxt4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 395, Short.MAX_VALUE)
            .addGroup(qrtxt4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(qrtxt4Layout.createSequentialGroup()
                    .addGap(178, 178, 178)
                    .addComponent(scan, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(179, Short.MAX_VALUE)))
        );

        jLabel30.setFont(new java.awt.Font("Microsoft Sans Serif", 1, 24)); // NOI18N
        jLabel30.setText("Scan QR Code Here");

        booktitle.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        booktitle.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                booktitleKeyPressed(evt);
            }
        });

        jLabel35.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel35.setText("Title of the book");

        author.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        author.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                authorKeyPressed(evt);
            }
        });

        jLabel36.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel36.setText("Author");

        jLabel37.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel37.setText("Book Acc. No.");

        booknum.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        booknum.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                booknumKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                booknumKeyTyped(evt);
            }
        });

        purposecb.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        purposecb.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select", "Borrow", "Return" }));
        purposecb.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                purposecbMouseClicked(evt);
            }
        });

        test.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        test.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                testKeyPressed(evt);
            }
        });

        myid.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        myid.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                myidKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                myidKeyTyped(evt);
            }
        });

        testing.setText("jTextField1");

        javax.swing.GroupLayout jPanel34Layout = new javax.swing.GroupLayout(jPanel34);
        jPanel34.setLayout(jPanel34Layout);
        jPanel34Layout.setHorizontalGroup(
            jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel34Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel34Layout.createSequentialGroup()
                        .addGroup(jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel34Layout.createSequentialGroup()
                                .addComponent(jLabel30)
                                .addGap(179, 179, 179))
                            .addGroup(jPanel34Layout.createSequentialGroup()
                                .addGroup(jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel35, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel36, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel37, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel34Layout.createSequentialGroup()
                                        .addComponent(lnametxt2, javax.swing.GroupLayout.PREFERRED_SIZE, 1, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(test, javax.swing.GroupLayout.PREFERRED_SIZE, 1, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(62, 62, 62)
                                        .addComponent(purposecb, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(booknum, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(author, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(booktitle, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 288, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(myid, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 6, Short.MAX_VALUE))
                    .addComponent(qrtxt4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(jPanel34Layout.createSequentialGroup()
                .addGap(155, 155, 155)
                .addComponent(testing, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel34Layout.setVerticalGroup(
            jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel34Layout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addComponent(jLabel30)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(qrtxt4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(booktitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel35))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(author, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel36))
                .addGap(14, 14, 14)
                .addGroup(jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(booknum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel37))
                .addGroup(jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel34Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lnametxt2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(test, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(purposecb, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18))
                    .addGroup(jPanel34Layout.createSequentialGroup()
                        .addGap(46, 46, 46)
                        .addComponent(myid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(16, 16, 16)
                        .addComponent(testing, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(133, Short.MAX_VALUE))))
        );

        jPanel35.setBackground(new java.awt.Color(255, 255, 255));
        jPanel35.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jTable5.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTable5KeyPressed(evt);
            }
        });
        jScrollPane6.setViewportView(jTable5);

        jPanel36.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jButton24.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jButton24.setText("Delete");
        jButton24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton24ActionPerformed(evt);
            }
        });

        jButton26.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jButton26.setText("Recycle Bin");
        jButton26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton26ActionPerformed(evt);
            }
        });

        jButton27.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jButton27.setText("Filter");
        jButton27.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton27ActionPerformed(evt);
            }
        });

        jButton28.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jButton28.setText("Clear");
        jButton28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton28ActionPerformed(evt);
            }
        });

        jButton29.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jButton29.setText("Print Reports");
        jButton29.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton29ActionPerformed(evt);
            }
        });

        jButton23.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jButton23.setText("Borrow");
        jButton23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton23ActionPerformed(evt);
            }
        });

        jButton33.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jButton33.setText("Return");
        jButton33.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton33ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel36Layout = new javax.swing.GroupLayout(jPanel36);
        jPanel36.setLayout(jPanel36Layout);
        jPanel36Layout.setHorizontalGroup(
            jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel36Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton33, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton23, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton29)
                .addGap(18, 18, 18)
                .addComponent(jButton28, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton27, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton24, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton26, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26))
        );
        jPanel36Layout.setVerticalGroup(
            jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel36Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton24, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton26, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton27, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton28, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton29, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton23, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton33, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        searchtxt2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 14)); // NOI18N

        jLabel31.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel31.setText("Search");

        jButton30.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 14)); // NOI18N
        jButton30.setText("Search");
        jButton30.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton30ActionPerformed(evt);
            }
        });

        courselb3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select", "BSIT", "BSA", "BSED", "BSHM", "BIT", "BSCE" }));

        jLabel32.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel32.setText("Filter by Course");

        toDateChooser1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                toDateChooser1KeyPressed(evt);
            }
        });

        jLabel33.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel33.setText("To:");

        fromDateChooser2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                fromDateChooser2KeyPressed(evt);
            }
        });

        jLabel34.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel34.setText("From:");

        javax.swing.GroupLayout jPanel37Layout = new javax.swing.GroupLayout(jPanel37);
        jPanel37.setLayout(jPanel37Layout);
        jPanel37Layout.setHorizontalGroup(
            jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel37Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel32)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(courselb3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel34)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(fromDateChooser2, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel33)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(toDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel31)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(searchtxt2, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton30, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(17, 17, 17))
        );
        jPanel37Layout.setVerticalGroup(
            jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel37Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(toDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel33)
                    .addComponent(fromDateChooser2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel34)
                    .addGroup(jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(searchtxt2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel31)
                        .addComponent(jButton30)
                        .addComponent(courselb3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel32)))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel35Layout = new javax.swing.GroupLayout(jPanel35);
        jPanel35.setLayout(jPanel35Layout);
        jPanel35Layout.setHorizontalGroup(
            jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel35Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel36, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel37, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane6))
                .addContainerGap())
        );
        jPanel35Layout.setVerticalGroup(
            jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel35Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel37, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel36, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel33Layout = new javax.swing.GroupLayout(jPanel33);
        jPanel33.setLayout(jPanel33Layout);
        jPanel33Layout.setHorizontalGroup(
            jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel33Layout.createSequentialGroup()
                .addComponent(jPanel34, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel35, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel33Layout.setVerticalGroup(
            jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel33Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel35, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel34, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel33, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel33, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("tab3", jPanel14);

        jPanel23.setBackground(new java.awt.Color(255, 255, 255));

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTable2KeyPressed(evt);
            }
        });
        jScrollPane3.setViewportView(jTable2);

        jButton12.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jButton12.setText("Delete");
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });

        jButton34.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jButton34.setText("Restore");
        jButton34.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton34ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel24Layout = new javax.swing.GroupLayout(jPanel24);
        jPanel24.setLayout(jPanel24Layout);
        jPanel24Layout.setHorizontalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel24Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton34, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(17, 17, 17))
        );
        jPanel24Layout.setVerticalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel24Layout.createSequentialGroup()
                .addContainerGap(19, Short.MAX_VALUE)
                .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton34, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(16, 16, 16))
        );

        search.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 14)); // NOI18N

        jButton13.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 14)); // NOI18N
        jButton13.setText("Search");
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });

        jLabel16.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel16.setText("Search");

        jLabel17.setFont(new java.awt.Font("Microsoft Sans Serif", 1, 24)); // NOI18N
        jLabel17.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel17.setText("Recycle Bin");

        sid.setText("jLabel18");

        isd2.setFont(new java.awt.Font("Microsoft Sans Serif", 1, 24)); // NOI18N
        isd2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        isd2.setText("Recycle Bin");

        javax.swing.GroupLayout jPanel23Layout = new javax.swing.GroupLayout(jPanel23);
        jPanel23.setLayout(jPanel23Layout);
        jPanel23Layout.setHorizontalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel23Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel23Layout.createSequentialGroup()
                        .addComponent(jLabel17)
                        .addGap(161, 161, 161)
                        .addComponent(isd2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 417, Short.MAX_VALUE)
                        .addComponent(sid, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(370, 370, 370)
                        .addComponent(jLabel16)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(search, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton13, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane3)
                    .addComponent(jPanel24, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel23Layout.setVerticalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel23Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(search, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16)
                    .addComponent(jButton13)
                    .addComponent(jLabel17)
                    .addComponent(sid)
                    .addComponent(isd2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 696, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel24, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("tab4", jPanel23);

        jPanel27.setBackground(new java.awt.Color(255, 231, 81));
        jPanel27.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        lnametxt1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        lnametxt1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                lnametxt1KeyPressed(evt);
            }
        });

        jLabel24.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel24.setText("Purpose");

        javax.swing.GroupLayout qrtxt3Layout = new javax.swing.GroupLayout(qrtxt3);
        qrtxt3.setLayout(qrtxt3Layout);
        qrtxt3Layout.setHorizontalGroup(
            qrtxt3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        qrtxt3Layout.setVerticalGroup(
            qrtxt3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 247, Short.MAX_VALUE)
        );

        jLabel27.setFont(new java.awt.Font("Microsoft Sans Serif", 1, 24)); // NOI18N
        jLabel27.setText("Scan QR Code Here");

        purposetxt.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        purposetxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                purposetxtKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jPanel27Layout = new javax.swing.GroupLayout(jPanel27);
        jPanel27.setLayout(jPanel27Layout);
        jPanel27Layout.setHorizontalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel27Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel27Layout.createSequentialGroup()
                        .addGap(0, 6, Short.MAX_VALUE)
                        .addGroup(jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel27Layout.createSequentialGroup()
                                .addComponent(jLabel27)
                                .addGap(120, 120, 120))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel27Layout.createSequentialGroup()
                                .addComponent(lnametxt1, javax.swing.GroupLayout.PREFERRED_SIZE, 1, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(423, 423, 423))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel27Layout.createSequentialGroup()
                        .addComponent(qrtxt3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel27Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel24)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(purposetxt, javax.swing.GroupLayout.PREFERRED_SIZE, 345, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel27Layout.setVerticalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel27Layout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addComponent(jLabel27)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(qrtxt3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(purposetxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel24))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lnametxt1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        jPanel28.setBackground(new java.awt.Color(255, 255, 255));
        jPanel28.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTable3KeyPressed(evt);
            }
        });
        jScrollPane4.setViewportView(jTable3);

        jPanel29.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jButton16.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jButton16.setText("Delete");
        jButton16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton16ActionPerformed(evt);
            }
        });

        jButton18.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jButton18.setText("Recycle Bin");
        jButton18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton18ActionPerformed(evt);
            }
        });

        jButton17.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jButton17.setText("Filter");
        jButton17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton17ActionPerformed(evt);
            }
        });

        jButton21.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jButton21.setText("Clear");
        jButton21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton21ActionPerformed(evt);
            }
        });

        jButton22.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jButton22.setText("Print Reports");
        jButton22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton22ActionPerformed(evt);
            }
        });

        jButton20.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jButton20.setText("Enter");
        jButton20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton20ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel29Layout = new javax.swing.GroupLayout(jPanel29);
        jPanel29.setLayout(jPanel29Layout);
        jPanel29Layout.setHorizontalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel29Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton20, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton22)
                .addGap(18, 18, 18)
                .addComponent(jButton21, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton17, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton16, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton18, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26))
        );
        jPanel29Layout.setVerticalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel29Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton16, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton18, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton17, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton21, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton22, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton20, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        searchtxt.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 14)); // NOI18N

        jLabel28.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel28.setText("Search");

        jButton19.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 14)); // NOI18N
        jButton19.setText("Search");
        jButton19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton19ActionPerformed(evt);
            }
        });

        courselb2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select", "BSIT", "BSA", "BSED", "BSHM", "BIT", "BSCE" }));

        jLabel29.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel29.setText("Filter by Course");

        toDateChooser.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                toDateChooserKeyPressed(evt);
            }
        });

        jLabel23.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel23.setText("To:");

        fromDateChooser.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                fromDateChooserKeyPressed(evt);
            }
        });

        jLabel25.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel25.setText("From:");

        javax.swing.GroupLayout jPanel30Layout = new javax.swing.GroupLayout(jPanel30);
        jPanel30.setLayout(jPanel30Layout);
        jPanel30Layout.setHorizontalGroup(
            jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel30Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel29)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(courselb2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 19, Short.MAX_VALUE)
                .addComponent(jLabel25)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(fromDateChooser, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel23)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(toDateChooser, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel28)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(searchtxt, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton19, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(17, 17, 17))
        );
        jPanel30Layout.setVerticalGroup(
            jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel30Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(toDateChooser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel23)
                    .addComponent(fromDateChooser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel25)
                    .addGroup(jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(searchtxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel28)
                        .addComponent(jButton19)
                        .addComponent(courselb2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel29)))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel28Layout = new javax.swing.GroupLayout(jPanel28);
        jPanel28.setLayout(jPanel28Layout);
        jPanel28Layout.setHorizontalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel28Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel29, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel30, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane4))
                .addContainerGap())
        );
        jPanel28Layout.setVerticalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel28Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel30, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 637, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel29, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel26Layout = new javax.swing.GroupLayout(jPanel26);
        jPanel26.setLayout(jPanel26Layout);
        jPanel26Layout.setHorizontalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel26Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel27, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel28, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel26Layout.setVerticalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel26Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel28, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel27, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel25Layout = new javax.swing.GroupLayout(jPanel25);
        jPanel25.setLayout(jPanel25Layout);
        jPanel25Layout.setHorizontalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel26, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 1512, Short.MAX_VALUE)
        );
        jPanel25Layout.setVerticalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel26, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("tab5", jPanel25);

        jPanel31.setBackground(new java.awt.Color(255, 255, 255));

        jTable4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTable4KeyPressed(evt);
            }
        });
        jScrollPane5.setViewportView(jTable4);

        jButton14.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jButton14.setText("Delete");
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });

        jButton35.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jButton35.setText("Restore");
        jButton35.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton35ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel32Layout = new javax.swing.GroupLayout(jPanel32);
        jPanel32.setLayout(jPanel32Layout);
        jPanel32Layout.setHorizontalGroup(
            jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel32Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton35, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton14, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(17, 17, 17))
        );
        jPanel32Layout.setVerticalGroup(
            jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel32Layout.createSequentialGroup()
                .addContainerGap(19, Short.MAX_VALUE)
                .addGroup(jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton14, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton35, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(16, 16, 16))
        );

        search3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 14)); // NOI18N

        jButton15.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 14)); // NOI18N
        jButton15.setText("Search");
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });

        jLabel19.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel19.setText("Search");

        jLabel20.setFont(new java.awt.Font("Microsoft Sans Serif", 1, 24)); // NOI18N
        jLabel20.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel20.setText("Logbook Recycle Bin");

        sid1.setText("jLabel18");

        idddd.setFont(new java.awt.Font("Microsoft Sans Serif", 1, 24)); // NOI18N
        idddd.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        idddd.setText("Logbook Recycle Bin");

        javax.swing.GroupLayout jPanel31Layout = new javax.swing.GroupLayout(jPanel31);
        jPanel31.setLayout(jPanel31Layout);
        jPanel31Layout.setHorizontalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel31Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel31Layout.createSequentialGroup()
                        .addComponent(jLabel20)
                        .addGap(28, 28, 28)
                        .addComponent(idddd, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 443, Short.MAX_VALUE)
                        .addComponent(sid1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(370, 370, 370)
                        .addComponent(jLabel19)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(search3, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton15, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane5)
                    .addComponent(jPanel32, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel31Layout.setVerticalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel31Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(search3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel19)
                    .addComponent(jButton15)
                    .addComponent(jLabel20)
                    .addComponent(sid1)
                    .addComponent(idddd))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 549, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel32, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1512, Short.MAX_VALUE)
            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel3Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel31, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 823, Short.MAX_VALUE)
            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel3Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel31, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        jTabbedPane1.addTab("tab6", jPanel3);

        jPanel38.setBackground(new java.awt.Color(255, 255, 255));

        jTable6.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable6.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTable6KeyPressed(evt);
            }
        });
        jScrollPane7.setViewportView(jTable6);

        jButton31.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jButton31.setText("Delete");
        jButton31.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton31ActionPerformed(evt);
            }
        });

        jButton36.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jButton36.setText("Restore");
        jButton36.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton36ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel39Layout = new javax.swing.GroupLayout(jPanel39);
        jPanel39.setLayout(jPanel39Layout);
        jPanel39Layout.setHorizontalGroup(
            jPanel39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel39Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton36, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton31, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(17, 17, 17))
        );
        jPanel39Layout.setVerticalGroup(
            jPanel39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel39Layout.createSequentialGroup()
                .addContainerGap(19, Short.MAX_VALUE)
                .addGroup(jPanel39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton31, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton36, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(16, 16, 16))
        );

        search1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 14)); // NOI18N

        jButton32.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 14)); // NOI18N
        jButton32.setText("Search");
        jButton32.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton32ActionPerformed(evt);
            }
        });

        jLabel38.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel38.setText("Search");

        jLabel39.setFont(new java.awt.Font("Microsoft Sans Serif", 1, 24)); // NOI18N
        jLabel39.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel39.setText("Borrow/ Return Recycle Bin");

        sid2.setText("jLabel18");

        id10.setFont(new java.awt.Font("Microsoft Sans Serif", 1, 24)); // NOI18N
        id10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        id10.setText("Borrow/ Return Recycle Bin");

        javax.swing.GroupLayout jPanel38Layout = new javax.swing.GroupLayout(jPanel38);
        jPanel38.setLayout(jPanel38Layout);
        jPanel38Layout.setHorizontalGroup(
            jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel38Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel38Layout.createSequentialGroup()
                        .addComponent(jLabel39)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 52, Short.MAX_VALUE)
                        .addComponent(id10, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(348, 348, 348)
                        .addComponent(sid2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(370, 370, 370)
                        .addComponent(jLabel38)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(search1, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton32, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane7)
                    .addComponent(jPanel39, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel38Layout.setVerticalGroup(
            jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel38Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(search1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel38)
                        .addComponent(jButton32)
                        .addComponent(sid2))
                    .addGroup(jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel39)
                        .addComponent(id10)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 551, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel39, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1512, Short.MAX_VALUE)
            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel7Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel38, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 823, Short.MAX_VALUE)
            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel7Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel38, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        jTabbedPane1.addTab("tab7", jPanel7);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1512, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );

        jPanel5.setBackground(new java.awt.Color(0, 0, 0));

        jPanel9.setBackground(new java.awt.Color(255, 153, 51));

        usernametxt2.setFont(new java.awt.Font("Microsoft Sans Serif", 1, 18)); // NOI18N
        usernametxt2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        usernametxt2.setText("Data Entry");
        usernametxt2.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 50, 1, 1));
        usernametxt2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                usernametxt2MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                usernametxt2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                usernametxt2MouseExited(evt);
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(usernametxt2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(usernametxt2, javax.swing.GroupLayout.DEFAULT_SIZE, 44, Short.MAX_VALUE)
        );

        jPanel10.setBackground(new java.awt.Color(255, 153, 51));
        jPanel10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel10MouseEntered(evt);
            }
        });

        usernametxt8.setFont(new java.awt.Font("Microsoft Sans Serif", 1, 18)); // NOI18N
        usernametxt8.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        usernametxt8.setText("Borrow/Return");
        usernametxt8.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 50, 1, 1));
        usernametxt8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                usernametxt8MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                usernametxt8MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                usernametxt8MouseExited(evt);
            }
        });

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(usernametxt8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(usernametxt8, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel11.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 14)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("User");
        jLabel1.setVerticalAlignment(javax.swing.SwingConstants.TOP);

        usernametxt.setFont(new java.awt.Font("Microsoft Sans Serif", 1, 18)); // NOI18N
        usernametxt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        usernametxt.setText("LIBRARIAN");
        usernametxt.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);

        jLabel40.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel40.setIcon(new javax.swing.ImageIcon(getClass().getResource("/allts/caps/user (2).png"))); // NOI18N

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(usernametxt, javax.swing.GroupLayout.DEFAULT_SIZE, 264, Short.MAX_VALUE)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel40, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel11Layout.createSequentialGroup()
                    .addGap(81, 81, 81)
                    .addComponent(icon)
                    .addContainerGap(81, Short.MAX_VALUE)))
            .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel11Layout.createSequentialGroup()
                    .addGap(91, 91, 91)
                    .addComponent(icon1)
                    .addContainerGap(161, Short.MAX_VALUE)))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(jLabel40, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(usernametxt, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1)
                .addGap(18, 18, 18))
            .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel11Layout.createSequentialGroup()
                    .addGap(40, 40, 40)
                    .addComponent(icon)
                    .addContainerGap(40, Short.MAX_VALUE)))
            .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel11Layout.createSequentialGroup()
                    .addGap(50, 50, 50)
                    .addComponent(icon1)
                    .addContainerGap(120, Short.MAX_VALUE)))
        );

        jPanel21.setBackground(new java.awt.Color(255, 153, 51));

        usernametxt3.setFont(new java.awt.Font("Microsoft Sans Serif", 1, 18)); // NOI18N
        usernametxt3.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        usernametxt3.setText("Logbook");
        usernametxt3.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 50, 1, 1));
        usernametxt3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                usernametxt3MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                usernametxt3MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                usernametxt3MouseExited(evt);
            }
        });

        javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
        jPanel21.setLayout(jPanel21Layout);
        jPanel21Layout.setHorizontalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(usernametxt3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel21Layout.setVerticalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(usernametxt3, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
        );

        jPanel22.setBackground(new java.awt.Color(255, 153, 51));

        usernametxt9.setFont(new java.awt.Font("Microsoft Sans Serif", 1, 18)); // NOI18N
        usernametxt9.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        usernametxt9.setText("Logout");
        usernametxt9.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 50, 1, 1));
        usernametxt9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                usernametxt9MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                usernametxt9MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                usernametxt9MouseExited(evt);
            }
        });

        javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);
        jPanel22Layout.setHorizontalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(usernametxt9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel22Layout.setVerticalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(usernametxt9, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 44, Short.MAX_VALUE)
        );

        jPanel40.setBackground(new java.awt.Color(255, 153, 51));

        usernametxt10.setFont(new java.awt.Font("Microsoft Sans Serif", 1, 18)); // NOI18N
        usernametxt10.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        usernametxt10.setText("Log Activity");
        usernametxt10.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 50, 1, 1));
        usernametxt10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                usernametxt10MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                usernametxt10MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                usernametxt10MouseExited(evt);
            }
        });

        javax.swing.GroupLayout jPanel40Layout = new javax.swing.GroupLayout(jPanel40);
        jPanel40.setLayout(jPanel40Layout);
        jPanel40Layout.setHorizontalGroup(
            jPanel40Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 264, Short.MAX_VALUE)
            .addGroup(jPanel40Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(usernametxt10, javax.swing.GroupLayout.DEFAULT_SIZE, 264, Short.MAX_VALUE))
        );
        jPanel40Layout.setVerticalGroup(
            jPanel40Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 44, Short.MAX_VALUE)
            .addGroup(jPanel40Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(usernametxt10, javax.swing.GroupLayout.DEFAULT_SIZE, 44, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel21, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel40, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel40, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

   
    
    private void usernametxt2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_usernametxt2MouseClicked
        jTabbedPane1.setSelectedIndex(1);
                snumbertxt.setText("");
        fnametxt.setText("");
        lnametxt.setText("");
        mnametxt.setText("");
        addresstxt.setText("");
        cnumbertxt.setText("");
        gnumbertxt.setText("");
        coursetxt.setSelectedItem("Select");
        yeartxt.setSelectedItem("Select");
        id12.setText("");
        stat.setText("");
        idd.setText("");
        idd1.setText("");
        fetchData(jTable1);
        

    }//GEN-LAST:event_usernametxt2MouseClicked

    private void usernametxt3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_usernametxt3MouseClicked
        jTabbedPane1.setSelectedIndex(4); 
           fetchData3(jTable3);
        initWebcam();
        
       test.setText("logbook");
        
    }//GEN-LAST:event_usernametxt3MouseClicked

    public void fetchStatus() {
                String studentId = snumbertxt.getText().trim();

                String url = "jdbc:mysql://localhost:3306/logbook_db?zeroDateTimeBehavior=CONVERT_TO_NULL";
                String username = "root";
                String password = "";

                String sql = "SELECT status FROM loggbook WHERE student_id = ? AND status = 1";

                try (Connection conn = DriverManager.getConnection(url, username, password);
                     PreparedStatement stmt = conn.prepareStatement(sql)) {

                    stmt.setString(1, studentId);

                    try (ResultSet rs = stmt.executeQuery()) {
                        if (rs.next()) {
                            int status = rs.getInt("status");
                            stat.setText(String.valueOf(status));
                        } else {
                            stat.setText("Not Found");
                        }
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Database error occurred.");
                }
            }
    
    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
       SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date fromDate = fromDateChooser1.getDate();
        Date toDate = toDateChoose1.getDate();
        String selectedCourse = courselb1.getSelectedItem().toString();
        String searchKeyword = searchtxt1.getText().trim();

        DefaultTableModel model = new DefaultTableModel(
             new String[] { "ID", "Date","Library Card Number", "Last Name", "First Name", "Middle Name", "Course", "Gender" }, 0
        );

        try (Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/logbook_db?zeroDateTimeBehavior=CONVERT_TO_NULL", "root", "")) {

            StringBuilder sql = new StringBuilder("SELECT * FROM tbl_user WHERE status = 0");
            List<Object> params = new ArrayList<>();

            if (fromDate != null && toDate != null) {
                sql.append(" AND datelb BETWEEN ? AND ?");
                params.add(sdf.format(fromDate));
                params.add(sdf.format(toDate));
            }

            if (!selectedCourse.equalsIgnoreCase("Select")) {
                sql.append(" AND course = ?");
                params.add(selectedCourse);
            }

            if (!searchKeyword.isEmpty()) {
                sql.append(" AND (firstName LIKE ? OR lastName LIKE ? OR middleName LIKE ?)");
                String pattern = "%" + searchKeyword + "%";
                params.add(pattern);
                params.add(pattern);
                params.add(pattern);
            }

            PreparedStatement pst = conn.prepareStatement(sql.toString());

            // Set dynamic parameters
            for (int i = 0; i < params.size(); i++) {
                pst.setObject(i + 1, params.get(i));
            }

            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("id"),
                    rs.getString("datelb"),
                    rs.getString("student_id"),
                    rs.getString("lastName"),
                    rs.getString("firstName"),
                    rs.getString("middleName"),
                    rs.getString("course"),
                    rs.getString("gender")
                    
                });
            }

            jTable1.setModel(model);

            // Hide the ID column
            jTable1.getColumnModel().getColumn(0).setMinWidth(0);
            jTable1.getColumnModel().getColumn(0).setMaxWidth(0);
            jTable1.getColumnModel().getColumn(0).setWidth(0);

            // Optional: Auto-resize columns

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error filtering data.");
        }
    }//GEN-LAST:event_jButton10ActionPerformed

    private void gnumbertxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_gnumbertxtKeyPressed
        generateqr();
        
//       String c_number = cnumbertxt.getText();
//       String g_number = gnumbertxt.getText();
//       
//       if (c_number.length() > 11 || g_number.length() > 11) {
//        JOptionPane.showMessageDialog(null, "Phone numbers must be 11 digits");
//        return;
//       }
        
    }//GEN-LAST:event_gnumbertxtKeyPressed

    private void usernametxt8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_usernametxt8MouseClicked
       jTabbedPane1.setSelectedIndex(2); 
       initWebcam1();
        scan.setVisible(true);
       test.setText("borrow");
       fetchData5(jTable5);
       
        jPanel34.setPreferredSize(new Dimension(440, 734));
    }//GEN-LAST:event_usernametxt8MouseClicked

    private void usernametxt9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_usernametxt9MouseClicked
       
       int confirm = JOptionPane.showConfirmDialog(null,"Are you sure you want to logout?", "Confirm logout", JOptionPane.YES_NO_OPTION);
                    if (confirm == JOptionPane.YES_OPTION) {
                        this.userId = userId;
            logActivity(conn, userId, "User logout");
                              this.dispose();
       
       login log = new login();
       log.show();
                    }

    }//GEN-LAST:event_usernametxt9MouseClicked

    private void lnametxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_lnametxtKeyPressed
          generateqr();
    }//GEN-LAST:event_lnametxtKeyPressed

    private void fnametxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_fnametxtKeyPressed
        generateqr();
    }//GEN-LAST:event_fnametxtKeyPressed

    private void mnametxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnametxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_mnametxtActionPerformed

    private void mnametxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_mnametxtKeyPressed
        generateqr();
    }//GEN-LAST:event_mnametxtKeyPressed

    private void snumbertxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_snumbertxtKeyPressed
        generateqr();
        

    }//GEN-LAST:event_snumbertxtKeyPressed

    private void addresstxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_addresstxtKeyPressed
      generateqr();
    }//GEN-LAST:event_addresstxtKeyPressed

    private void cnumbertxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cnumbertxtKeyPressed
       generateqr();
       
//       String c_number = cnumbertxt.getText();
//       String g_number = gnumbertxt.getText();
//       
//       if (c_number.length() > 11 || g_number.length() > 11) {
//            JOptionPane.showMessageDialog(null, "Phone numbers must be 15 digits or fewer.");
//            return;
//        }

  
    }//GEN-LAST:event_cnumbertxtKeyPressed

    
    public boolean isStudentIdExists(String studentId) {
    boolean exists = false;

    String query = "SELECT COUNT(*) FROM tbl_user WHERE student_id = ?";
    
    try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/logbook_db?zeroDateTimeBehavior=CONVERT_TO_NULL", "root", "");
         PreparedStatement pst = con.prepareStatement(query)) {
        
        pst.setString(1, studentId);
        ResultSet rs = pst.executeQuery();

        if (rs.next()) {
            exists = rs.getInt(1) > 0; // true if count > 0
        }

        rs.close();
    } catch (SQLException ex) {
        ex.printStackTrace(); // or show a dialog
    }

    return exists;
}
    
    
    private void cnumbertxtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cnumbertxtKeyTyped
             char c = evt.getKeyChar();

        // Allow only numbers (digits) and control characters (backspace, etc.)
        if (!Character.isDigit(c)) {
            evt.consume(); // Discard the non-numeric key press
        }
    }//GEN-LAST:event_cnumbertxtKeyTyped

    private void gnumbertxtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_gnumbertxtKeyTyped
                    char c = evt.getKeyChar();

        // Allow only numbers (digits) and control characters (backspace, etc.)
        if (!Character.isDigit(c)) {
            evt.consume(); // Discard the non-numeric key press
        }
    }//GEN-LAST:event_gnumbertxtKeyTyped

    private void snumbertxtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_snumbertxtKeyTyped
                     char c = evt.getKeyChar();

        // Allow only numbers (digits) and control characters (backspace, etc.)
        if (!Character.isDigit(c)) {
            evt.consume(); // Discard the non-numeric key press
        }
 
        
    }//GEN-LAST:event_snumbertxtKeyTyped

    private void jTable1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable1KeyPressed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
     String student_id = snumbertxt.getText();  // or get from selected JTable row
        if (!student_id.isEmpty()) {
            softDeleteUser(student_id);
            fetchData(jTable1);
            this.userId = userId;
            logActivity(conn, userId, "Delete student");
        } else {
            JOptionPane.showMessageDialog(null, "Please enter or select a student to delete.");
        }
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
          jTabbedPane1.setSelectedIndex(3); 
          fetchData2(jTable2);
          
        Font headerFont = new Font("Arial", Font.BOLD, 15);  // Customize font for header
        Font font = new Font("Arial", Font.PLAIN, 14);
        JTableHeader header = jTable2.getTableHeader();
        header.setFont(headerFont);
        jTable2.setFont(font);
        jTable2.setRowHeight(30); 
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jTable2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable2KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable2KeyPressed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        String student_id = sid.getText();  // or get from selected JTable row
        if (!student_id.isEmpty()) {
            deleteUser(student_id);
            fetchData2(jTable2);
        } else {
            JOptionPane.showMessageDialog(null, "Please enter or select a student to delete.");
        }       
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
        String searchKeyword = search.getText();

        DefaultTableModel model = new DefaultTableModel(
             new String[] { "ID", "Date","Library Card Number", "First Name", "Last Name", "Middle Name", "Course", "Gender" }, 0
        );

        try (Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/logbook_db?zeroDateTimeBehavior=CONVERT_TO_NULL", "root", "")) {

            StringBuilder sql = new StringBuilder("SELECT * FROM tbl_user WHERE status = 1");
            List<Object> params = new ArrayList<>();

            if (!searchKeyword.isEmpty()) {
                sql.append(" AND (firstName LIKE ? OR lastName LIKE ? OR middleName LIKE ?)");
                String pattern = "%" + searchKeyword + "%";
                params.add(pattern);
                params.add(pattern);
                params.add(pattern);
            }

            PreparedStatement pst = conn.prepareStatement(sql.toString());

            // Set dynamic parameters
            for (int i = 0; i < params.size(); i++) {
                pst.setObject(i + 1, params.get(i));
            }

            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("id"),
                    rs.getString("datelb"),
                    rs.getString("student_id"),
                    rs.getString("lastName"),
                    rs.getString("firstName"),
                    rs.getString("middleName"),
                    rs.getString("course"),
                    rs.getString("gender")
                    
                });
            }

            jTable2.setModel(model);

            // Hide the ID column
            jTable2.getColumnModel().getColumn(0).setMinWidth(0);
            jTable2.getColumnModel().getColumn(0).setMaxWidth(0);
            jTable2.getColumnModel().getColumn(0).setWidth(0);

            // Optional: Auto-resize columns

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error filtering data.");
        }
    }//GEN-LAST:event_jButton13ActionPerformed

    private void lnametxt1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_lnametxt1KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_lnametxt1KeyPressed

    private void jTable3KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable3KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable3KeyPressed

    private void jButton16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton16ActionPerformed
        String id = idd1.getText();
        
        softDeleteUser1(id);
        
        fetchData3(jTable3);
        
                       this.userId = userId;
            logActivity(conn, userId, "Delete a logbook record");
    }//GEN-LAST:event_jButton16ActionPerformed

    private void jButton18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton18ActionPerformed
        jTabbedPane1.setSelectedIndex(5); 
        fetchData4(jTable4);
          
        Font headerFont = new Font("Arial", Font.BOLD, 15);  // Customize font for header
        Font font = new Font("Arial", Font.PLAIN, 14);
        JTableHeader header = jTable4.getTableHeader();
        header.setFont(headerFont);
        jTable4.setFont(font);
        jTable4.setRowHeight(30); 
    }//GEN-LAST:event_jButton18ActionPerformed

    private void jButton19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton19ActionPerformed

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
Date fromDate = fromDateChooser.getDate();
Date toDate = toDateChooser.getDate();
String selectedCourse = courselb2.getSelectedItem().toString();
String searchKeyword = searchtxt.getText().trim();

DefaultTableModel model = new DefaultTableModel(
    new String[]{"ID", "Date", "Last Name", "First Name", "Middle Name", "Gender", "Course", "Purpose", "Time in", "Time Out", "Contact Number"}, 0
);

try (Connection conn = DriverManager.getConnection(
        "jdbc:mysql://localhost:3306/logbook_db?zeroDateTimeBehavior=CONVERT_TO_NULL", "root", "")) {

    StringBuilder sql = new StringBuilder("SELECT * FROM loggbook WHERE delete_status = 0");
    List<Object> params = new ArrayList<>();

    if (fromDate != null && toDate != null) {
        sql.append(" AND datelb BETWEEN ? AND ?");
        params.add(sdf.format(fromDate));
        params.add(sdf.format(toDate));
    }

    if (!selectedCourse.equalsIgnoreCase("Select")) {
        sql.append(" AND courselb = ?");
        params.add(selectedCourse);
    }

    if (!searchKeyword.isEmpty()) {
        sql.append(" AND (fnamelb LIKE ? OR lnamelb LIKE ? OR mnamelb LIKE ?)");
        String pattern = "%" + searchKeyword + "%";
        params.add(pattern);
        params.add(pattern);
        params.add(pattern);
    }

    PreparedStatement pst = conn.prepareStatement(sql.toString());

    // Set dynamic parameters
    for (int i = 0; i < params.size(); i++) {
        pst.setObject(i + 1, params.get(i));
    }

    ResultSet rs = pst.executeQuery();

    while (rs.next()) {
        model.addRow(new Object[]{
            rs.getString("id"),
            rs.getString("datelb"),
            rs.getString("lnamelb"),
            rs.getString("fnamelb"),
            rs.getString("mnamelb"),
            rs.getString("genderlb"),
            rs.getString("courselb"),
            rs.getString("purposelb"),
            rs.getString("timein_lb"),
            rs.getString("timeout_lb"),
            rs.getString("numberlb")
        });
    }

    jTable3.setModel(model);

    // Hide the ID column
    jTable3.getColumnModel().getColumn(0).setMinWidth(0);
    jTable3.getColumnModel().getColumn(0).setMaxWidth(0);
    jTable3.getColumnModel().getColumn(0).setWidth(0);

    // Optional: Auto-resize columns
    autoResizeColumnWidths(jTable3); // If you already have this method

} catch (SQLException ex) {
    ex.printStackTrace();
    JOptionPane.showMessageDialog(null, "Error filtering data.");
}

                  
    }//GEN-LAST:event_jButton19ActionPerformed

    private void cnumbertxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cnumbertxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cnumbertxtActionPerformed

    private void yeartxtItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_yeartxtItemStateChanged
        generateqr();
        
        
    }//GEN-LAST:event_yeartxtItemStateChanged

    private void coursetxtItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_coursetxtItemStateChanged
        generateqr();
    }//GEN-LAST:event_coursetxtItemStateChanged

    private void snumbertxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_snumbertxtKeyReleased
        String studentId = snumbertxt.getText().trim();

        if (isStudentIdExists(studentId)) {
            JOptionPane.showMessageDialog(null, "Student ID already exists!", "Duplicate ID", JOptionPane.WARNING_MESSAGE);
            snumbertxt.setText("");
             qrtxt.removeAll();
        qrtxt.setLayout(new FlowLayout()); 
        qrtxt.setPreferredSize(new Dimension(qrtxt.getWidth(), 175));
        qrtxt.revalidate();
        qrtxt.repaint();
        }
        
       
        
    }//GEN-LAST:event_snumbertxtKeyReleased


    
    
    private void purposetxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_purposetxtKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_purposetxtKeyPressed

    private void jButton20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton20ActionPerformed
      
        
       
    String student_id = snumbertxt.getText();
    String firstName = fnametxt.getText();
    String lastName = lnametxt.getText();
    String middleName = mnametxt.getText();
    String course = (String) coursetxt.getSelectedItem();
    String year = (String) yeartxt.getSelectedItem();
    String purpose = purposetxt.getText();
    String status = stat.getText();
    
    String st = stat.getText();

    String timenow_in = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"));
    String time_in = timenow_in;
    String number = cnumbertxt.getText();
    
    String datenow = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
    String date_lb = datenow;
    
    if (purpose.isEmpty() && snumbertxt.getText().isEmpty()) {
        JOptionPane.showMessageDialog(null, "Please enter your purpose Or Scan Another QR Code.");
    } else if (st.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Please Scan Your QR Code Or Fill out the fields");
    }else if (!purpose.isEmpty() && snumbertxt.getText().isEmpty()) {
        JOptionPane.showMessageDialog(null, "Please Scan Your QR Code Or Fill out the fields");
    }
    else {
        if ("1".equals(status)) {
            updateStatus(conn, student_id);
        } else {
            insertUserLb(student_id, lastName, firstName, middleName,
                course, year, purpose, time_in, number, date_lb);

            snumbertxt.setText("");
            fnametxt.setText("");
            lnametxt.setText("");
            mnametxt.setText("");
            addresstxt.setText("");
            cnumbertxt.setText("");
            gnumbertxt.setText("");
            coursetxt.setSelectedItem("Select");
            yeartxt.setSelectedItem("Select");
            purposetxt.setText("");

            qrtxt.removeAll();
            qrtxt.setLayout(new FlowLayout());
            qrtxt.setPreferredSize(new Dimension(qrtxt.getWidth(), 175));
            qrtxt.revalidate();
            qrtxt.repaint();
            snumbertxt.setEnabled(true);
            
                        this.userId = userId;
            logActivity(conn, userId, "Student Logbooked");
            fetchData(jTable1);
            
            scan.setVisible(true);
        }

        fetchData3(jTable3);
    }

       
    


        
    }//GEN-LAST:event_jButton20ActionPerformed

    private void lnametxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lnametxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_lnametxtActionPerformed

    private void lnametxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_lnametxtKeyReleased


    }//GEN-LAST:event_lnametxtKeyReleased

    private void statKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_statKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_statKeyPressed

    private void statKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_statKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_statKeyTyped

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed

        String student_id = snumbertxt.getText();
        String firstName = fnametxt.getText();
        String lastName = lnametxt.getText();
        String middleName = mnametxt.getText();
        String course = (String) coursetxt.getSelectedItem();
        String year = (String) yeartxt.getSelectedItem();
        String address = addresstxt.getText();
        String cnumber = cnumbertxt.getText();
        String gnumber = gnumbertxt.getText();

        // Check if all fields are filled AND course/year are NOT "Select"
        if (!student_id.isEmpty() && !firstName.isEmpty() && !lastName.isEmpty() &&
            !middleName.isEmpty() && !course.isEmpty() && !year.isEmpty() &&
            !address.isEmpty() && !cnumber.isEmpty() && !gnumber.isEmpty() &&
            !course.equals("Select") && !year.equals("Select")) {

            dashboard db = new dashboard(userId);
            db.insertUser(
                student_id,
                firstName,
                lastName,
                middleName,
                course,
                year,
                address,
                cnumber,
                gnumber,
                qrtxt
            );
            this.userId = userId;
            logActivity(conn, userId, "Add student");

            fetchData(jTable1);

        } else {
            JOptionPane.showMessageDialog(null, "Please input all fields and select a valid course and year.");
        }

    }//GEN-LAST:event_jButton7ActionPerformed

        public void logActivity(Connection conn, int studentId, String action) {
            String sql = "INSERT INTO log_activity (student_id, action) VALUES (?, ?)";

            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, studentId);
                pstmt.setString(2, action);
                pstmt.executeUpdate();
                System.out.println("Activity logged: " + action);
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Failed to log activity: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    
    
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        String student_id = snumbertxt.getText();
        String firstName = fnametxt.getText();
        String lastName = lnametxt.getText();
        String middleName = mnametxt.getText();
        String course = (String) coursetxt.getSelectedItem();
        String year = (String) yeartxt.getSelectedItem();
        String address = addresstxt.getText();
        String c_number = cnumbertxt.getText();
        String g_number = gnumbertxt.getText();

        try {
            String checkSql = "SELECT COUNT(*) FROM tbl_user WHERE student_id = ?";
            PreparedStatement checkStmt = conn.prepareStatement(checkSql);
            checkStmt.setString(1, student_id);
            ResultSet rs = checkStmt.executeQuery();

            if (!rs.next() || rs.getInt(1) == 0) {
                // Student ID does not exist
                JOptionPane.showMessageDialog(null, "Student ID not found. Cannot update non-existing record.");
                return;
            }else{

                if (!student_id.isEmpty() && !firstName.isEmpty() && !lastName.isEmpty() &&
                    !middleName.isEmpty() && !course.isEmpty() && !year.isEmpty() &&
                    !address.isEmpty() && !c_number.isEmpty() && !g_number.isEmpty() &&
                    !course.equals("Select") && !year.equals("Select")) {

                    int confirm = JOptionPane.showConfirmDialog(null,"Are you sure you want to update this user?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
                    if (confirm == JOptionPane.YES_OPTION) {
                        // Call your update method (make sure 'conn' and 'qrtxt' are accessible)
                        updateUser(student_id, firstName, lastName, middleName, course, year, address, c_number, g_number, qrtxt);
                                              this.userId = userId;
            logActivity(conn, userId, "Update student record");
                        fetchData(jTable1);
                    }

                }else{
                    JOptionPane.showMessageDialog(null, "There are no data in fields");

                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Login error: " + e.getMessage());
        }

    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed

        snumbertxt.setText("");
        fnametxt.setText("");
        lnametxt.setText("");
        mnametxt.setText("");
        addresstxt.setText("");
        cnumbertxt.setText("");
        gnumbertxt.setText("");
        coursetxt.setSelectedItem("Select");
        yeartxt.setSelectedItem("Select");

        qrtxt.removeAll();
        qrtxt.setLayout(new FlowLayout());
        qrtxt.setPreferredSize(new Dimension(qrtxt.getWidth(), 175));
        qrtxt.revalidate();
        qrtxt.repaint();
        snumbertxt.setEnabled(true);
        fetchData(jTable1);

    }//GEN-LAST:event_jButton9ActionPerformed

    private void jTable4KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable4KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable4KeyPressed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
        String student_id = sid1.getText();
        if (!student_id.isEmpty()) {
            deleteUser1(student_id);
            fetchData4(jTable4);
        } else {
            JOptionPane.showMessageDialog(null, "Please enter or select a student to delete.");
        } 
    }//GEN-LAST:event_jButton14ActionPerformed

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
       String searchKeyword = search3.getText();

DefaultTableModel model = new DefaultTableModel(
    new String[]{"ID", "Date", "First Name", "Last Name", "Middle Name", "Gender", "Course", "Purpose", "Time in", "Time Out", "Contact Number"}, 0
);

try (Connection conn = DriverManager.getConnection(
        "jdbc:mysql://localhost:3306/logbook_db?zeroDateTimeBehavior=CONVERT_TO_NULL", "root", "")) {

    StringBuilder sql = new StringBuilder("SELECT * FROM loggbook WHERE delete_status = 1");
    List<Object> params = new ArrayList<>();


    if (!searchKeyword.isEmpty()) {
        sql.append(" AND (fnamelb LIKE ? OR lnamelb LIKE ? OR mnamelb LIKE ?)");
        String pattern = "%" + searchKeyword + "%";
        params.add(pattern);
        params.add(pattern);
        params.add(pattern);
    }

    PreparedStatement pst = conn.prepareStatement(sql.toString());

    // Set dynamic parameters
    for (int i = 0; i < params.size(); i++) {
        pst.setObject(i + 1, params.get(i));
    }

    ResultSet rs = pst.executeQuery();

    while (rs.next()) {
        model.addRow(new Object[]{
            rs.getString("id"),
            rs.getString("datelb"),
            rs.getString("lnamelb"),
            rs.getString("fnamelb"),
            rs.getString("mnamelb"),
            rs.getString("genderlb"),
            rs.getString("courselb"),
            rs.getString("purposelb"),
            rs.getString("timein_lb"),
            rs.getString("timeout_lb"),
            rs.getString("numberlb")
        });
    }

    jTable4.setModel(model);

    // Hide the ID column
    jTable4.getColumnModel().getColumn(0).setMinWidth(0);
    jTable4.getColumnModel().getColumn(0).setMaxWidth(0);
    jTable4.getColumnModel().getColumn(0).setWidth(0);


} catch (SQLException ex) {
    ex.printStackTrace();
    JOptionPane.showMessageDialog(null, "Error filtering data.");
}
    }//GEN-LAST:event_jButton15ActionPerformed

    private void toDateChooserKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_toDateChooserKeyPressed
    
        
    }//GEN-LAST:event_toDateChooserKeyPressed

    private void fromDateChooserKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_fromDateChooserKeyPressed

    }//GEN-LAST:event_fromDateChooserKeyPressed

    private void jButton17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton17ActionPerformed
    if (fromDateChooser.getDate() != null && toDateChooser.getDate() != null) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date fromDate = fromDateChooser.getDate(); 
        Date toDate = toDateChooser.getDate();

        if (fromDate == null || toDate == null) {
            JOptionPane.showMessageDialog(null, "Please select both FROM and TO dates.");
            return;
        }

        String from = sdf.format(fromDate);
        String to = sdf.format(toDate);
        String selectedCourse = courselb2.getSelectedItem().toString();

        DefaultTableModel model = new DefaultTableModel(
            new String[]{"ID", "Date", "First Name", "Last Name", "Middle Name", "Gender", "Course", "Purpose", "Time in", "Time Out", "Contact Number"}, 0
        );

        try (Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/logbook_db?zeroDateTimeBehavior=CONVERT_TO_NULL", "root", "")) {

            PreparedStatement pst;

            // Check if the selected course is not the default "Select"
            if (!selectedCourse.equalsIgnoreCase("Select")) {
                pst = conn.prepareStatement(
                    "SELECT * FROM loggbook WHERE datelb BETWEEN ? AND ? AND courselb = ?"
                );
                pst.setString(1, from);
                pst.setString(2, to);
                pst.setString(3, selectedCourse);
            } else {
                // No course filter
                pst = conn.prepareStatement(
                    "SELECT * FROM loggbook WHERE datelb BETWEEN ? AND ?"
                );
                pst.setString(1, from);
                pst.setString(2, to);
            }

            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("id"),
                    rs.getString("datelb"),
                    rs.getString("lnamelb"),
                    rs.getString("fnamelb"),
                    rs.getString("mnamelb"),
                    rs.getString("genderlb"),
                    rs.getString("courselb"),
                    rs.getString("purposelb"),
                    rs.getString("timein_lb"),
                    rs.getString("timeout_lb"),
                    rs.getString("numberlb")
                });
            }

            jTable3.setModel(model);

            // Hide the ID column
            jTable3.getColumnModel().getColumn(0).setMinWidth(0);
            jTable3.getColumnModel().getColumn(0).setMaxWidth(0);
            jTable3.getColumnModel().getColumn(0).setWidth(0);

            autoResizeColumnWidths(jTable3);

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error filtering data.");
        }
    } else {
        JOptionPane.showMessageDialog(null, "Please select the date.");
    }


    }//GEN-LAST:event_jButton17ActionPerformed

    private void jButton21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton21ActionPerformed
        courselb2.setSelectedItem("Select");
       fromDateChooser.setDate(null);
       toDateChooser.setDate(null);
       searchtxt.setText("");
       
        fetchData3(jTable3);
    }//GEN-LAST:event_jButton21ActionPerformed

    private void jButton22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton22ActionPerformed
       saveTableToPDF(jTable3);
                      this.userId = userId;
            logActivity(conn, userId, "Print a logbook records");
    }//GEN-LAST:event_jButton22ActionPerformed

public void saveTableToPDF(JTable table) {
    try {
        Document document = new Document(PageSize.A4.rotate(), 50, 50, 50, 50);
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Save PDF File");
        fileChooser.setSelectedFile(new java.io.File("Logbook_Report.pdf"));
        int userSelection = fileChooser.showSaveDialog(null);

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            String filePath = fileChooser.getSelectedFile().getAbsolutePath();
            if (!filePath.endsWith(".pdf")) {
                filePath += ".pdf";
            }

            PdfWriter.getInstance(document, new FileOutputStream(filePath));
            document.open();

            // Title
            com.itextpdf.text.Font titleFont = new com.itextpdf.text.Font(
                com.itextpdf.text.Font.FontFamily.HELVETICA,
                18,
                com.itextpdf.text.Font.BOLD
            );
            Paragraph title = new Paragraph("LOGBOOK REPORT", titleFont);
            title.setAlignment(Element.ALIGN_CENTER);
            title.setSpacingAfter(20f);
            document.add(title);
            
            Date fromDate = fromDateChooser.getDate();
            Date toDate = toDateChooser.getDate();

            SimpleDateFormat sdf = new SimpleDateFormat("MMMM dd, yyyy"); // E.g., May 20, 2025

            String from = (fromDate != null) ? sdf.format(fromDate) : "";
            String to = (toDate != null) ? sdf.format(toDate) : "";

            Paragraph titles = new Paragraph("From: " + from + "    TO: " + to, titleFont);
            titles.setAlignment(Element.ALIGN_CENTER);
            titles.setSpacingAfter(20f);
            document.add(titles);

            // Create PDF Table with 10 columns (excluding ID)
            PdfPTable pdfTable = new PdfPTable(10);
            pdfTable.setWidthPercentage(100);
            pdfTable.setSpacingBefore(10f);

            // Column headers
            String[] headers = {
                "Date", "Last Name", "First Name", "Middle Name",
                "Gender", "Course", "Purpose", "Time In", "Time Out", "Contact Number"
            };

            for (String header : headers) {
                PdfPCell headerCell = new PdfPCell(new Phrase(header));
                headerCell.setBackgroundColor(BaseColor.LIGHT_GRAY);
                headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
                pdfTable.addCell(headerCell);
            }

            // TableModel
            TableModel model = table.getModel();
            int rowCount = model.getRowCount();
            int columnCount = model.getColumnCount();

            for (int row = 0; row < rowCount; row++) {
                // Start from column 1 to skip the ID (col 0)
                for (int col = 1; col < columnCount; col++) {
                    Object value = model.getValueAt(row, col);
                    pdfTable.addCell(value != null ? value.toString() : "");
                }
            }

            document.add(pdfTable);
            document.close();

            JOptionPane.showMessageDialog(null, "PDF generated successfully!");
        }

    } catch (Exception ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error generating PDF: " + ex.getMessage());
    }
}

    private void jButton25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton25ActionPerformed
      
    try {
        String id = id12.getText().trim();
        String lastname = lnametxt.getText().trim();     // Assuming you have a text field for last name
        String firstname = fnametxt.getText().trim();    // Assuming you have a text field for first name

        if (qrtxt.getComponentCount() == 0) {
            JOptionPane.showMessageDialog(null, "No QR Code found in the panel.");
            return;
        }

        // Get the displayed QR code from qrtxt panel
        Component comp = qrtxt.getComponent(0);
        if (!(comp instanceof JLabel)) {
            JOptionPane.showMessageDialog(null, "QR Code is not in the expected format.");
            return;
        }

        JLabel qrLabel = (JLabel) comp;
        Icon icon = qrLabel.getIcon();
        if (!(icon instanceof ImageIcon)) {
            JOptionPane.showMessageDialog(null, "QR Code icon is not an ImageIcon.");
            return;
        }

        ImageIcon imageIcon = (ImageIcon) icon;
        Image original = imageIcon.getImage();

        // Convert to BufferedImage
        BufferedImage originalImage = new BufferedImage(
            original.getWidth(null), original.getHeight(null), BufferedImage.TYPE_INT_ARGB);
        Graphics2D gOriginal = originalImage.createGraphics();
        gOriginal.drawImage(original, 0, 0, null);
        gOriginal.dispose();

        // Create HD image (512x512)
        int hdWidth = 512;
        int hdHeight = 512;
        BufferedImage hdImage = new BufferedImage(hdWidth, hdHeight, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = hdImage.createGraphics();

        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        g2d.drawImage(originalImage, 0, 0, hdWidth, hdHeight, null);
        g2d.dispose();

        // Suggested filename
        String defaultFileName = lastname + "_" + firstname + "_" + id + ".png";

        // Save dialog
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Save HD QR Code As PNG");
        fileChooser.setSelectedFile(new File(defaultFileName));
        int userSelection = fileChooser.showSaveDialog(null);

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();

            // Ensure PNG extension
            String filePath = fileToSave.getAbsolutePath();
            if (!filePath.toLowerCase().endsWith(".png")) {
                fileToSave = new File(filePath + ".png");
            }

            // Save image
            boolean success = ImageIO.write(hdImage, "png", fileToSave);
            if (success) {
                JOptionPane.showMessageDialog(null, "HD QR Code saved successfully!");
            } else {
                JOptionPane.showMessageDialog(null, "Failed to save QR Code.");
            }
        }

    } catch (Exception ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
    }

    }//GEN-LAST:event_jButton25ActionPerformed

    private void id12KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_id12KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_id12KeyPressed

    private void id12KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_id12KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_id12KeyTyped

    private void lnametxt2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_lnametxt2KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_lnametxt2KeyPressed

    private void jButton23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton23ActionPerformed
        String student_id = snumbertxt.getText();
        String firstName = fnametxt.getText();
        String lastName = lnametxt.getText();
        String middleName = mnametxt.getText();
        String course = (String) coursetxt.getSelectedItem();
        String year = (String) yeartxt.getSelectedItem();
        
        String purpose = (String) purposecb.getSelectedItem();
        String bookname = booktitle.getText();
        String bookauth = author.getText();
        String booknumber = booknum.getText();
        if("".equals(bookauth) || "".equals(booknumber) || "".equals(bookname) || "".equals(student_id)){
            JOptionPane.showMessageDialog(null, "Please Fill out all Fileds! or scan your QR code");
        }else{
            
                insertUserBr(student_id, firstName, lastName, middleName,
                course, year, bookname, booknumber, bookauth);
            
            
                    booknum.setText("");
                    booktitle.setText("");
                    author.setText("");
                    purposecb.setSelectedItem("Select");
                    snumbertxt.setText("");
                    fnametxt.setText("");
                    lnametxt.setText("");
                    mnametxt.setText("");
                    addresstxt.setText("");
                    cnumbertxt.setText("");
                    gnumbertxt.setText("");
                    coursetxt.setSelectedItem("Select");
                    yeartxt.setSelectedItem("Select");
                    id12.setText("");
                    stat.setText("");
                    idd.setText("");
                    idd1.setText("");
                    
                    scan.setVisible(true);
                                this.userId = userId;
            logActivity(conn, userId, "Add students that borrowed");
                    fetchData5(jTable5);
            
                    
        }
        
        
        
    }//GEN-LAST:event_jButton23ActionPerformed

    private void jTable5KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable5KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable5KeyPressed

    private void jButton24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton24ActionPerformed
        String id = idd1.getText();
        
        softDeleteUser2(id);
                    this.userId = userId;
            logActivity(conn, userId, "delete a borrowed book");
        
        fetchData5(jTable5);
    }//GEN-LAST:event_jButton24ActionPerformed

    private void jButton26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton26ActionPerformed
        jTabbedPane1.setSelectedIndex(6);
        fetchData6(jTable6);
        
    }//GEN-LAST:event_jButton26ActionPerformed

    private void jButton27ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton27ActionPerformed
       if (fromDateChooser2.getDate() != null && toDateChooser1.getDate() != null) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date fromDate = fromDateChooser2.getDate(); 
        Date toDate = toDateChooser1.getDate();

        if (fromDate == null || toDate == null) {
            JOptionPane.showMessageDialog(null, "Please select both FROM and TO dates.");
            return;
        }

        String from = sdf.format(fromDate);
        String to = sdf.format(toDate);
        String selectedCourse = courselb3.getSelectedItem().toString();

        DefaultTableModel model = new DefaultTableModel(
            new String[] {"ID", "Date", "Last Name", "First Name", "Middle Name", "Gender", "Course" , "Purpose", "Book Title" , "Author" , "Book Acc. No."}, 0
        );

        try (Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/logbook_db?zeroDateTimeBehavior=CONVERT_TO_NULL", "root", "")) {

            PreparedStatement pst;

            // Check if the selected course is not the default "Select"
            if (!selectedCourse.equalsIgnoreCase("Select")) {
                pst = conn.prepareStatement(
                    "SELECT * FROM tbl_borrow WHERE datebr BETWEEN ? AND ? AND department = ?"
                );
                pst.setString(1, from);
                pst.setString(2, to);
                pst.setString(3, selectedCourse);
            } else {
                // No course filter
                pst = conn.prepareStatement(
                    "SELECT * FROM tbl_borrow WHERE datebr BETWEEN ? AND ?"
                );
                pst.setString(1, from);
                pst.setString(2, to);
            }

            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("id"),
                    rs.getString("datebr"),
                    rs.getString("lastName"),
                    rs.getString("firstName"),
                    rs.getString("middleName"),
                    rs.getString("gender"),
                    rs.getString("department"),
                    rs.getString("purpose"),
                    rs.getString("book_title"),
                    rs.getString("author"),
                    rs.getString("book_acc_no")
                });
            }

            jTable5.setModel(model);

            // Hide the ID column
            jTable5.getColumnModel().getColumn(0).setMinWidth(0);
            jTable5.getColumnModel().getColumn(0).setMaxWidth(0);
            jTable5.getColumnModel().getColumn(0).setWidth(0);

            resizeColumnWidths(jTable5);

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error filtering data.");
        }
    } else {
        JOptionPane.showMessageDialog(null, "Please select the date.");
    }
    }//GEN-LAST:event_jButton27ActionPerformed

    private void jButton28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton28ActionPerformed
        booknum.setText("");
        booktitle.setText("");
        author.setText("");
        purposecb.setSelectedItem("Select");
        courselb2.setSelectedItem("Select");
       fromDateChooser.setDate(null);
       toDateChooser.setDate(null);
       searchtxt.setText("");
        
        
    }//GEN-LAST:event_jButton28ActionPerformed

    private void jButton29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton29ActionPerformed
       saveTableToPDF1(jTable5);
                   this.userId = userId;
            logActivity(conn, userId, "Print a report");
    }//GEN-LAST:event_jButton29ActionPerformed

    public void saveTableToPDF1(JTable table) {
    try {
                    
        Date fromDate = fromDateChooser2.getDate();
        Date toDate = toDateChooser1.getDate();
        SimpleDateFormat sdf = new SimpleDateFormat("MMMM dd, yyyy"); // E.g., May 20, 2025

            String from = (fromDate != null) ? sdf.format(fromDate) : "";
            String to = (toDate != null) ? sdf.format(toDate) : "";
        Document document = new Document(PageSize.A4.rotate(), 50, 50, 50, 50);
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Save PDF File");
        fileChooser.setSelectedFile(new java.io.File("Borrow&Return_Report.pdf"));
        int userSelection = fileChooser.showSaveDialog(null);

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            String filePath = fileChooser.getSelectedFile().getAbsolutePath();
            if (!filePath.endsWith(".pdf")) {
                filePath += ".pdf";
            }

            PdfWriter.getInstance(document, new FileOutputStream(filePath));
            document.open();

            // Title
            com.itextpdf.text.Font titleFont = new com.itextpdf.text.Font(
                com.itextpdf.text.Font.FontFamily.HELVETICA,
                18,
                com.itextpdf.text.Font.BOLD
            );
            Paragraph title = new Paragraph("BORROW & RETURN REPORT", titleFont);
            title.setAlignment(Element.ALIGN_CENTER);
            title.setSpacingAfter(20f);
            document.add(title);


            

            Paragraph titles = new Paragraph("From: " + from + "    TO: " + to, titleFont);
            titles.setAlignment(Element.ALIGN_CENTER);
            titles.setSpacingAfter(20f);
            document.add(titles);

            // Create PDF Table with 10 columns (excluding ID)
            PdfPTable pdfTable = new PdfPTable(10);
            pdfTable.setWidthPercentage(100);
            pdfTable.setSpacingBefore(10f);

            // Column headers
            String[] headers = {
                "Date", "Last Name", "First Name", "Middle Name",
                "Gender", "Course", "Purpose", "Title fo the book", "Author", "Book Acc. No."
            };

            for (String header : headers) {
                PdfPCell headerCell = new PdfPCell(new Phrase(header));
                headerCell.setBackgroundColor(BaseColor.LIGHT_GRAY);
                headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
                pdfTable.addCell(headerCell);
            }

            // TableModel
            TableModel model = table.getModel();
            int rowCount = model.getRowCount();
            int columnCount = model.getColumnCount();

            for (int row = 0; row < rowCount; row++) {
                // Start from column 1 to skip the ID (col 0)
                for (int col = 1; col < columnCount; col++) {
                    Object value = model.getValueAt(row, col);
                    pdfTable.addCell(value != null ? value.toString() : "");
                }
            }

            document.add(pdfTable);
            document.close();

            JOptionPane.showMessageDialog(null, "PDF generated successfully!");
        }

    } catch (Exception ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error generating PDF: " + ex.getMessage());
    }
}
    
    private void jButton30ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton30ActionPerformed
        
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                Date fromDate = fromDateChooser2.getDate();
                Date toDate = toDateChooser1.getDate();
                String selectedCourse = courselb3.getSelectedItem().toString();
                String searchKeyword = searchtxt2.getText().trim();

                DefaultTableModel model = new DefaultTableModel(
                    new String[] {"ID", "Date", "Last Name", "First Name", "Middle Name", "Gender", "Course" , "Purpose", "Book Title" , "Author" , "Book Acc. No."}, 0
                );

        try (Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/logbook_db?zeroDateTimeBehavior=CONVERT_TO_NULL", "root", "")) {

            StringBuilder sql = new StringBuilder("SELECT * FROM tbl_borrow WHERE status = 0");
            List<Object> params = new ArrayList<>();

            if (fromDate != null && toDate != null) {
                sql.append(" AND datebr BETWEEN ? AND ?");
                params.add(sdf.format(fromDate));
                params.add(sdf.format(toDate));
            }

            if (!selectedCourse.equalsIgnoreCase("Select")) {
                sql.append(" AND department = ?");
                params.add(selectedCourse);
            }

            if (!searchKeyword.isEmpty()) {
                sql.append(" AND (firstName LIKE ? OR lastName LIKE ? OR middleName LIKE ?)");
                String pattern = "%" + searchKeyword + "%";
                params.add(pattern);
                params.add(pattern);
                params.add(pattern);
            }

            PreparedStatement pst = conn.prepareStatement(sql.toString());

            // Set dynamic parameters
            for (int i = 0; i < params.size(); i++) {
                pst.setObject(i + 1, params.get(i));
            }

            ResultSet rs = pst.executeQuery();

                    while (rs.next()) {
                        model.addRow(new Object[]{
                            rs.getString("id"),
                            rs.getString("datebr"),
                            rs.getString("lastName"),
                            rs.getString("firstName"),
                            rs.getString("middleName"),
                            rs.getString("gender"),
                            rs.getString("department"),
                            rs.getString("purpose"),
                            rs.getString("book_title"),
                            rs.getString("author"),
                            rs.getString("book_acc_no")
                        });
                    }

            jTable5.setModel(model);

            // Hide the ID column
            jTable5.getColumnModel().getColumn(0).setMinWidth(0);
            jTable5.getColumnModel().getColumn(0).setMaxWidth(0);
            jTable5.getColumnModel().getColumn(0).setWidth(0);

            // Optional: Auto-resize columns
            resizeColumnWidths(jTable5); // If you already have this method

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error filtering data.");
        }
    }//GEN-LAST:event_jButton30ActionPerformed

    private void toDateChooser1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_toDateChooser1KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_toDateChooser1KeyPressed

    private void fromDateChooser2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_fromDateChooser2KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_fromDateChooser2KeyPressed

    private void booktitleKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_booktitleKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_booktitleKeyPressed

    private void authorKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_authorKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_authorKeyPressed

    private void booknumKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_booknumKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_booknumKeyPressed

    private void testKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_testKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_testKeyPressed

    private void booknumKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_booknumKeyTyped
        char c = evt.getKeyChar();

        // Allow only numbers (digits) and control characters (backspace, etc.)
        if (!Character.isDigit(c)) {
            evt.consume(); // Discard the non-numeric key press
        }
    }//GEN-LAST:event_booknumKeyTyped

    private void scanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_scanActionPerformed
      
      scan.setVisible(false);
      String lb =  test.getText();
      
      if("logbook".equals(lb)){
        initWebcam();
        }else if ("borrow".equals(lb)) {
            initWebcam1();
        }
      
    }//GEN-LAST:event_scanActionPerformed

    private void purposecbMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_purposecbMouseClicked
            
        int height = jPanel34.getHeight();
        int width = jPanel34.getWidth();

        System.out.println(height + " " + width);

        jPanel34.setPreferredSize(new Dimension(width, height));
    }//GEN-LAST:event_purposecbMouseClicked

    private void jTable6KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable6KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable6KeyPressed

    private void jButton31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton31ActionPerformed
           String student_id = sid2.getText();
        if (!student_id.isEmpty()) {
            deleteUser3(student_id);
            fetchData6(jTable6);
        } else {
            JOptionPane.showMessageDialog(null, "Please enter or select a student to delete.");
        } 
    }//GEN-LAST:event_jButton31ActionPerformed

    private void jButton32ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton32ActionPerformed
        String searchKeyword = search1.getText();

                DefaultTableModel model = new DefaultTableModel(
                    new String[] {"ID", "Date", "Last Name", "First Name", "Middle Name", "Gender", "Course" , "Purpose", "Book Title" , "Author" , "Book Acc. No."}, 0
                );

        try (Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/logbook_db?zeroDateTimeBehavior=CONVERT_TO_NULL", "root", "")) {

            StringBuilder sql = new StringBuilder("SELECT * FROM tbl_borrow WHERE status = 1");
            List<Object> params = new ArrayList<>();


            if (!searchKeyword.isEmpty()) {
                sql.append(" AND (firstName LIKE ? OR lastName LIKE ? OR middleName LIKE ?)");
                String pattern = "%" + searchKeyword + "%";
                params.add(pattern);
                params.add(pattern);
                params.add(pattern);
            }

            PreparedStatement pst = conn.prepareStatement(sql.toString());

            // Set dynamic parameters
            for (int i = 0; i < params.size(); i++) {
                pst.setObject(i + 1, params.get(i));
            }

            ResultSet rs = pst.executeQuery();

                    while (rs.next()) {
                        model.addRow(new Object[]{
                            rs.getString("id"),
                            rs.getString("datebr"),
                            rs.getString("lastName"),
                            rs.getString("firstName"),
                            rs.getString("middleName"),
                            rs.getString("gender"),
                            rs.getString("department"),
                            rs.getString("purpose"),
                            rs.getString("book_title"),
                            rs.getString("author"),
                            rs.getString("book_acc_no")
                        });
                    }

            jTable6.setModel(model);

            // Hide the ID column
            jTable6.getColumnModel().getColumn(0).setMinWidth(0);
            jTable6.getColumnModel().getColumn(0).setMaxWidth(0);
            jTable6.getColumnModel().getColumn(0).setWidth(0);


        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error filtering data.");
        }
    }//GEN-LAST:event_jButton32ActionPerformed

    private void myidKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_myidKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_myidKeyPressed

    private void myidKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_myidKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_myidKeyTyped

    private void jButton33ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton33ActionPerformed

        int confirm = JOptionPane.showConfirmDialog(null, 
            "Are you sure you want to return?", "Confirm Return", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
        
        
        int id = Integer.parseInt(myid.getText().trim());       
                
                    String url = "jdbc:mysql://localhost:3306/logbook_db?zeroDateTimeBehavior=CONVERT_TO_NULL";
                    String username = "root";
                    String password = "";

                     String currentDate = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                     String sql = "UPDATE tbl_borrow SET purpose = 'Return', datebr = ? WHERE id = ?";

                    try (Connection conn = DriverManager.getConnection(url, username, password);
                         PreparedStatement stmt = conn.prepareStatement(sql)) {
                        stmt.setString(1, currentDate);
                        stmt.setInt(2, id);

                        int rowsUpdated = stmt.executeUpdate();
                        if (rowsUpdated > 0) {
                            JOptionPane.showMessageDialog(null, "Return successfully!");
                             booknum.setText("");
                            booktitle.setText("");
                            author.setText("");
                            purposecb.setSelectedItem("Select");
                            courselb2.setSelectedItem("Select");
                           fromDateChooser.setDate(null);
                           toDateChooser.setDate(null);
                           searchtxt.setText("");
                           
                                       this.userId = userId;
            logActivity(conn, userId, "Return a book");
                            fetchData5(jTable5);
                        } else {
                            JOptionPane.showMessageDialog(null, "No record found with ID: " + id);
                        }

                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
        }
    }//GEN-LAST:event_jButton33ActionPerformed

    private void usernametxt2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_usernametxt2MouseEntered
        jPanel9.setBackground(DefaultColor);       
    }//GEN-LAST:event_usernametxt2MouseEntered

    private void usernametxt8MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_usernametxt8MouseEntered
       jPanel10.setBackground(DefaultColor);   
    }//GEN-LAST:event_usernametxt8MouseEntered

    private void jPanel10MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel10MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel10MouseEntered

    private void usernametxt3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_usernametxt3MouseEntered
       jPanel21.setBackground(DefaultColor);   
    }//GEN-LAST:event_usernametxt3MouseEntered

    private void usernametxt9MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_usernametxt9MouseEntered
        jPanel22.setBackground(DefaultColor);
    }//GEN-LAST:event_usernametxt9MouseEntered

    private void usernametxt9MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_usernametxt9MouseExited
       jPanel22.setBackground(DefaultColorExit);
    }//GEN-LAST:event_usernametxt9MouseExited

    private void usernametxt3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_usernametxt3MouseExited
       jPanel21.setBackground(DefaultColorExit);
    }//GEN-LAST:event_usernametxt3MouseExited

    private void usernametxt8MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_usernametxt8MouseExited
       jPanel10.setBackground(DefaultColorExit);   
    }//GEN-LAST:event_usernametxt8MouseExited

    private void usernametxt2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_usernametxt2MouseExited
        jPanel9.setBackground(DefaultColorExit); 
    }//GEN-LAST:event_usernametxt2MouseExited

    private void jButton34ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton34ActionPerformed
        
        if (!isd2.getText().isEmpty()) {
            softDeleteUser7(isd2.getText());
            this.userId = userId;
            logActivity(conn, userId, "Restore deleted student record");
            fetchData2(jTable2);
        } else {
            JOptionPane.showMessageDialog(null, "Please enter or select a student to delete.");
        }  
    }//GEN-LAST:event_jButton34ActionPerformed

    private void jButton35ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton35ActionPerformed
        String id = idddd.getText();
//        softDeleteUser9(id);
        int confirm = JOptionPane.showConfirmDialog(null, 
            "Are you sure you want to restore this user?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try {
                String sql = "UPDATE loggbook SET delete_status = 0 WHERE id = ?";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, id);

                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(null, "User restore successfully!");
                    this.userId = userId;
            logActivity(conn, userId, "Restore deleted student logbook record");
                } else {
                    JOptionPane.showMessageDialog(null, "No user found with the given Student ID.");
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error updating user status.");
            }
        }
        
        fetchData4(jTable4);
    }//GEN-LAST:event_jButton35ActionPerformed

    
    public void softDeleteUser9(String student_id) {
        int confirm = JOptionPane.showConfirmDialog(null, 
            "Are you sure you want to restore this user?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try {
                String sql = "UPDATE loggbook SET delete_status = 0 WHERE id = ?";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, student_id);

                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(null, "User restore successfully!");
                } else {
                    JOptionPane.showMessageDialog(null, "No user found with the given Student ID.");
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error updating user status.");
            }
        }
    }
    private void jButton36ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton36ActionPerformed
       String id = id10.getText();
        
        int confirm = JOptionPane.showConfirmDialog(null, 
            "Are you sure you want to restore this user?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try {
                String sql = "UPDATE tbl_borrow SET status = 0 WHERE id = ?";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, id);

                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(null, "User restore successfully!");
                    this.userId = userId;
                    logActivity(conn, userId, "Restore deleted student record on borrow/return");
                } else {
                    JOptionPane.showMessageDialog(null, "No user found with the given Student ID.");
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error updating user status.");
            }
        }
        
        fetchData6(jTable6);
    }//GEN-LAST:event_jButton36ActionPerformed

    private void searchtxt1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchtxt1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchtxt1ActionPerformed

    private void usernametxt10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_usernametxt10MouseClicked
          jTabbedPane1.setSelectedIndex(0);  
 
        Font headerFont6 = new Font("Arial", Font.BOLD, 15);  // Customize font for header
        Font font6 = new Font("Arial", Font.PLAIN, 14);
        JTableHeader header6 = jTable7.getTableHeader();
        header6.setFont(headerFont6);

        jTable7.setFont(font6);
        jTable7.setRowHeight(30); 
        
        
       Connection conn = null;
    PreparedStatement pst = null;
    ResultSet rs = null;

    try {
        String url = "jdbc:mysql://localhost:3306/logbook_db";
        String user = "root";
        String password = "";

        conn = DriverManager.getConnection(url, user, password);

        String sql = "SELECT id, student_id, action, log_time FROM log_activity WHERE student_id = ?";
        pst = conn.prepareStatement(sql);
        pst.setInt(1, userId);

        rs = pst.executeQuery();
        
                // Define column headers
        String[] columns = { "Action", "Log Time"};

        // Create a DefaultTableModel with columns and zero rows initially
        DefaultTableModel model = new DefaultTableModel(columns, 0);

        // Set this model to your JTable
        jTable7.setModel(model);

        // Populate the table model with database rows
        while (rs.next()) {
//            int id = rs.getInt("id");
            String action = rs.getString("action");
            Timestamp logTime = rs.getTimestamp("log_time");

            model.addRow(new Object[]{action, logTime});
        }

    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error loading data: " + e.getMessage());
    } finally {
        try {
            if (rs != null) rs.close();
            if (pst != null) pst.close();
            if (conn != null) conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    }//GEN-LAST:event_usernametxt10MouseClicked

    private void usernametxt10MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_usernametxt10MouseEntered
       jPanel40.setBackground(DefaultColor);   
    }//GEN-LAST:event_usernametxt10MouseEntered

    private void usernametxt10MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_usernametxt10MouseExited
       jPanel40.setBackground(DefaultColorExit);  
    }//GEN-LAST:event_usernametxt10MouseExited

    private void jTable7KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable7KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable7KeyPressed
  
    public void softDeleteUser10(String student_id) {
        int confirm = JOptionPane.showConfirmDialog(null, 
            "Are you sure you want to restore this user?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try {
                String sql = "UPDATE tbl_borrow SET status = 0 WHERE id = ?";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, student_id);

                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(null, "User restore successfully!");
                } else {
                    JOptionPane.showMessageDialog(null, "No user found with the given Student ID.");
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error updating user status.");
            }
        }
    }
    public void softDeleteUser7(String student_id) {
        int confirm = JOptionPane.showConfirmDialog(null, 
            "Are you sure you want to restore this user?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try {
                String sql = "UPDATE tbl_user SET status = 0 WHERE id = ?";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, student_id);

                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(null, "User restore successfully!");
                } else {
                    JOptionPane.showMessageDialog(null, "No user found with the given Student ID.");
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error updating user status.");
            }
        }
    }
    
public void updateStatus(Connection conn, String studentId) {
    String timeOut = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"));
    
    // Step 1: Get the latest record ID where status = 1 (already timed in and out)
    String selectSql = "SELECT id FROM loggbook WHERE student_id = ? AND status = 1 ORDER BY id DESC LIMIT 1";
    
    try (PreparedStatement selectStmt = conn.prepareStatement(selectSql)) {
        selectStmt.setString(1, studentId);
        ResultSet rs = selectStmt.executeQuery();
        
        if (rs.next()) {
            int latestId = rs.getInt("id"); // Last completed log

            // Step 2: Update this record (example: just showing update — can be adjusted to your logic)
            String updateSql = "UPDATE loggbook SET timeout_lb = ?, status = 0 WHERE id = ?";

            try (PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {
                updateStmt.setString(1, timeOut);
                updateStmt.setInt(2, latestId);

                int rowsUpdated = updateStmt.executeUpdate();

                if (rowsUpdated > 0) {
                    purposetxt.setText("");
                     JOptionPane.showMessageDialog(null, "Logbook time out successfully!");
                     fetchData3(jTable3);
                } else {
                    System.out.println("Update failed for student_id: " + studentId);
                }
            }

        } else {
            System.out.println("No previous log with status=1 found for student_id: " + studentId);
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }
}

    public static void insertUserBr(String studentId, String firstName, String lastName, String middleName, String course, String yearLevel , String booktitle,  String boooknumber, String bookauthr) {
        String url = "jdbc:mysql://localhost:3306/logbook_db?zeroDateTimeBehavior=CONVERT_TO_NULL";
        String username = "root";
        String password = "";

        String sql = "INSERT INTO tbl_borrow (student_idbr, lastName, firstName, middleName, gender, department, book_title, author, book_acc_no) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(url, username, password);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, studentId);
            stmt.setString(2, lastName);
            stmt.setString(3, firstName);
            stmt.setString(4, middleName);
            stmt.setString(5, yearLevel);
            stmt.setString(6, course);
            stmt.setString(7, booktitle);
            stmt.setString(8, bookauthr);
            stmt.setString(9, boooknumber);

            int rowsInserted = stmt.executeUpdate();
            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(null, "Data inserted successfully!");
              
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    
    public static void insertUserLb(String studentId, String firstName, String lastName, String middleName, String course, String yearLevel ,String purpose, String timein,  String number, String lb_date) {
        String url = "jdbc:mysql://localhost:3306/logbook_db?zeroDateTimeBehavior=CONVERT_TO_NULL";
        String username = "root";
        String password = "";

        String sql = "INSERT INTO loggbook (student_id, lnamelb, fnamelb, mnamelb, genderlb, courselb, purposelb, timein_lb, numberlb, datelb, status) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)";

        try (Connection conn = DriverManager.getConnection(url, username, password);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, studentId);
            stmt.setString(2, firstName);
            stmt.setString(3, lastName);
            stmt.setString(4, middleName);
            stmt.setString(5, yearLevel);
            stmt.setString(6, course);
            stmt.setString(7, purpose);
            stmt.setString(8, timein);
            stmt.setString(9, number);
            stmt.setString(10, lb_date);

            int rowsInserted = stmt.executeUpdate();
            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(null, "Logbook time in successfully!");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    
    public void softDeleteUser(String student_id) {
        int confirm = JOptionPane.showConfirmDialog(null, 
            "Are you sure you want to delete this user?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try {
                String sql = "UPDATE tbl_user SET status = 1 WHERE student_id = ?";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, student_id);

                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(null, "User deleted successfully!");
                } else {
                    JOptionPane.showMessageDialog(null, "No user found with the given Student ID.");
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error updating user status.");
            }
        }
    }
    
    public void softDeleteUser1(String student_id) {
        int confirm = JOptionPane.showConfirmDialog(null, 
            "Are you sure you want to delete this user?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try {
                String sql = "UPDATE loggbook SET delete_status = 1 WHERE id = ?";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, student_id);

                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(null, "User deleted successfully!");
                } else {
                    JOptionPane.showMessageDialog(null, "No user found with the given Student ID.");
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error updating user status.");
            }
        }
    }
    
    public void softDeleteUser2(String student_id) {
        int confirm = JOptionPane.showConfirmDialog(null, 
            "Are you sure you want to delete this user?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try {
                String sql = "UPDATE tbl_borrow SET status = 1 WHERE id = ?";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, student_id);

                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(null, "User deleted successfully!");
                } else {
                    JOptionPane.showMessageDialog(null, "No user found with the given Student ID.");
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error updating user status.");
            }
        }
    }
    
    
        public static void fetchData(JTable table) {
            // Create connection to the database
            String url = "jdbc:mysql://localhost:3306/logbook_db?zeroDateTimeBehavior=CONVERT_TO_NULL"; // Replace with your database details
            String user = "root"; // Replace with your username
            String password = ""; // Replace with your password

            // Query to fetch data from tbl_user
            String query = "SELECT id, datelb, student_id, firstName, lastName, middleName, course, gender FROM tbl_user WHERE status = 0";

            try (Connection conn = DriverManager.getConnection(url, user, password);
                 Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(query)) {

                        // Create a custom table model with column names
                DefaultTableModel model = new DefaultTableModel(
                    new String[] {"ID", "Date", "Library Card Number", "Last Name", "First Name", "Middle Name", "Course", "Gender"}, 0) {
                    // Override the isCellEditable method to return false for all cells
                    @Override
                    public boolean isCellEditable(int row, int column) {
                        return false;  // Disable editing for all cells
                    }
                };
                // Loop through the result set and add rows to the table model
                while (rs.next()) {
                    String id = rs.getString("id");
                    String datelb = rs.getString("datelb");
                    String student_id = rs.getString("student_id");
                    String lastName = rs.getString("lastName");
                    String firstName = rs.getString("firstName");
                    String middleName = rs.getString("middleName");
                    String course = rs.getString("course");
                    String year = rs.getString("gender");
//                    byte[] qr_code = rs.getBytes("qr_code"); // For storing QR Code as byte array

                    // Add the data as a row to the table model
                    model.addRow(new Object[] { id, datelb, student_id, lastName, firstName, middleName, course, year});
                }

                // Set the table model to the JTable
                table.setModel(model);
                
                table.getColumnModel().getColumn(0).setMinWidth(0);
                table.getColumnModel().getColumn(0).setMaxWidth(0);
                table.getColumnModel().getColumn(0).setWidth(0);
                

            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error fetching data from database.");
            }
        }
        
public static void fetchData5(JTable table) {
    String url = "jdbc:mysql://localhost:3306/logbook_db?zeroDateTimeBehavior=CONVERT_TO_NULL";
    String user = "root";
    String password = "";
    String query = "SELECT id, datebr, lastName, firstName, middleName, gender, department, purpose, book_title, author, book_acc_no FROM tbl_borrow WHERE status = 0";

    try (Connection conn = DriverManager.getConnection(url, user, password);
         Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(query)) {

        DefaultTableModel model = new DefaultTableModel(
            new String[] {"ID", "Date", "Last Name", "First Name", "Middle Name", "Gender", "Course", "Purpose", "Book Title", "Author", "Book Acc. No.", "Penalty", "Fine"}, 0) {

            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        while (rs.next()) {
            String id = rs.getString("id");
            Date dateBrSql = rs.getDate("datebr");
            String datelb = dateBrSql != null ? dateBrSql.toString() : "";
            String lastName = rs.getString("lastName");
            String firstName = rs.getString("firstName");
            String middleName = rs.getString("middleName");
            String gender = rs.getString("gender");
            String course = rs.getString("department");
            String purpose = rs.getString("purpose");
            String booktitle = rs.getString("book_title");
            String author = rs.getString("author");
            String book_acc_no = rs.getString("book_acc_no");

            // Default values
            String penalty = "NO";
            String fineStr = "₱0";

            if (!"Return".equalsIgnoreCase(purpose)) {
                if (dateBrSql != null) {
                    LocalDate now = LocalDate.now();
                    LocalDate dateBr = ((java.sql.Date) dateBrSql).toLocalDate();
                    long daysBetween = ChronoUnit.DAYS.between(dateBr, now);

                    if (daysBetween > 4) {
                        penalty = "YES";
                    }
                    

                    if (daysBetween >= 1 && "YES".equals(penalty)) {
                        int fineAmount = (int) daysBetween * 300;
                        fineStr = "₱" + fineAmount;
                    }
                }
            }

            model.addRow(new Object[] {
                id, datelb, lastName, firstName, middleName, gender, course, purpose,
                booktitle, author, book_acc_no, penalty, fineStr
            });
        }

        table.setModel(model);

        // Hide ID column
        table.getColumnModel().getColumn(0).setMinWidth(0);
        table.getColumnModel().getColumn(0).setMaxWidth(0);
        table.getColumnModel().getColumn(0).setWidth(0);

        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        resizeColumnWidths(table);

    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error fetching data from database.");
    }
}
    
//        public static void fetchData5(JTable table) {
//            // Create connection to the database
//            String url = "jdbc:mysql://localhost:3306/logbook_db?zeroDateTimeBehavior=CONVERT_TO_NULL"; // Replace with your database details
//            String user = "root"; // Replace with your username
//            String password = ""; // Replace with your password
//
//            // Query to fetch data from tbl_user
//            String query = "SELECT id, datebr, lastName, firstName, middleName, gender, department, purpose, book_title, author, book_acc_no, penalty, fines FROM tbl_borrow WHERE status = 0";
//
//            try (Connection conn = DriverManager.getConnection(url, user, password);
//                 Statement stmt = conn.createStatement();
//                 ResultSet rs = stmt.executeQuery(query)) {
//
//                        // Create a custom table model with column names
//                DefaultTableModel model = new DefaultTableModel(
//                    new String[] {"ID", "Date", "Last Name", "First Name", "Middle Name", "Gender", "Course" , "Purpose", "Book Title" , "Author" , "Book Acc. No.", "Penalty", "Fine"}, 0) {
//                    // Override the isCellEditable method to return false for all cells
//                    @Override
//                    public boolean isCellEditable(int row, int column) {
//                        return false;  // Disable editing for all cells
//                    }
//                };
//                // Loop through the result set and add rows to the table model
//                while (rs.next()) {
//                    String id = rs.getString("id");
//                    String datelb = rs.getString("datebr");
//                    String lastName = rs.getString("lastName");
//                    String firstName = rs.getString("firstName");
//                    String middleName = rs.getString("middleName");
//                    String year = rs.getString("gender");
//                    String course = rs.getString("department");
//                    String purpose = rs.getString("purpose");
//                    String booktitle = rs.getString("book_title");
//                    String author = rs.getString("author");
//                    String boock_acc = rs.getString("book_acc_no");
//                    String penalty = rs.getString("penalty");
//                    String fines = rs.getString("fines");
////                    byte[] qr_code = rs.getBytes("qr_code"); // For storing QR Code as byte array
//
//                    // Add the data as a row to the table model
//                    model.addRow(new Object[] { id, datelb, lastName, firstName, middleName, year, course, purpose, booktitle, author, boock_acc, penalty, fines});
//                }
//
//                // Set the table model to the JTable
//                table.setModel(model);
//                
//                table.getColumnModel().getColumn(0).setMinWidth(0);
//                table.getColumnModel().getColumn(0).setMaxWidth(0);
//                table.getColumnModel().getColumn(0).setWidth(0);
//                
//                // Turn off auto resize so we can set preferred widths manually
//                table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
//
//                // Resize columns to fit content
//                resizeColumnWidths(table);
//                
//
//            } catch (SQLException e) {
//                e.printStackTrace();
//                JOptionPane.showMessageDialog(null, "Error fetching data from database.");
//            }
//        }

        public static void fetchData6(JTable table) {
            // Create connection to the database
            String url = "jdbc:mysql://localhost:3306/logbook_db?zeroDateTimeBehavior=CONVERT_TO_NULL"; // Replace with your database details
            String user = "root"; // Replace with your username
            String password = ""; // Replace with your password

            // Query to fetch data from tbl_user
            String query = "SELECT id, datebr, lastName, firstName, middleName, gender, department, purpose, book_title, author, book_acc_no FROM tbl_borrow WHERE status = 1";

            try (Connection conn = DriverManager.getConnection(url, user, password);
                 Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(query)) {

                        // Create a custom table model with column names
                DefaultTableModel model = new DefaultTableModel(
                    new String[] {"ID", "Date", "Last Name", "First Name", "Middle Name", "Gender", "Course" , "Purpose", "Book Title" , "Author" , "Book Acc. No."}, 0) {
                    // Override the isCellEditable method to return false for all cells
                    @Override
                    public boolean isCellEditable(int row, int column) {
                        return false;  // Disable editing for all cells
                    }
                };
                // Loop through the result set and add rows to the table model
                while (rs.next()) {
                    String id = rs.getString("id");
                    String datelb = rs.getString("datebr");
                    String lastName = rs.getString("lastName");
                    String firstName = rs.getString("firstName");
                    String middleName = rs.getString("middleName");
                    String year = rs.getString("gender");
                    String course = rs.getString("department");
                    String purpose = rs.getString("purpose");
                    String booktitle = rs.getString("book_title");
                    String author = rs.getString("author");
                    String boock_acc = rs.getString("book_acc_no");
//                    byte[] qr_code = rs.getBytes("qr_code"); // For storing QR Code as byte array

                    // Add the data as a row to the table model
                    model.addRow(new Object[] { id, datelb, lastName, firstName, middleName, year, course, purpose, booktitle, author, boock_acc});
                }

                // Set the table model to the JTable
                table.setModel(model);
                
                table.getColumnModel().getColumn(0).setMinWidth(0);
                table.getColumnModel().getColumn(0).setMaxWidth(0);
                table.getColumnModel().getColumn(0).setWidth(0);
                
                

            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error fetching data from database.");
            }
        }

    public static void fetchData2(JTable table) {
            // Create connection to the database
            String url = "jdbc:mysql://localhost:3306/logbook_db?zeroDateTimeBehavior=CONVERT_TO_NULL"; // Replace with your database details
            String user = "root"; // Replace with your username
            String password = ""; // Replace with your password

            // Query to fetch data from tbl_user
            String query = "SELECT id, datelb, student_id, firstName, lastName, middleName, course, gender FROM tbl_user WHERE status = 1";

            try (Connection conn = DriverManager.getConnection(url, user, password);
                 Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(query)) {

                        // Create a custom table model with column names
                DefaultTableModel model = new DefaultTableModel(
                    new String[] {"ID","Date", "Library Card Number", "First Name", "Last Name", "Middle Name", "Course", "Gender" }, 0) {
                    // Override the isCellEditable method to return false for all cells
                    @Override
                    public boolean isCellEditable(int row, int column) {
                        return false;  // Disable editing for all cells
                    }
                };
                // Loop through the result set and add rows to the table model
                while (rs.next()) {
                    String idd = rs.getString("id");
                    String datelb = rs.getString("datelb");
                    String student_id = rs.getString("student_id");
                    String firstName = rs.getString("firstName");
                    String lastName = rs.getString("lastName");
                    String middleName = rs.getString("middleName");
                    String course = rs.getString("course");
                    String year = rs.getString("gender");
//                    byte[] qr_code = rs.getBytes("qr_code"); // For storing QR Code as byte array

                    // Add the data as a row to the table model
                    model.addRow(new Object[] {idd, datelb, student_id, firstName, lastName, middleName, course, year});
                }

                // Set the table model to the JTable
                table.setModel(model);
                
                                
                table.getColumnModel().getColumn(0).setMinWidth(0);
                table.getColumnModel().getColumn(0).setMaxWidth(0);
                table.getColumnModel().getColumn(0).setWidth(0);
                
                

            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error fetching data from database.");
            }
        }
    
   public static void fetchData3(JTable table) {
    String url = "jdbc:mysql://localhost:3306/logbook_db?zeroDateTimeBehavior=CONVERT_TO_NULL";
    String user = "root";
    String password = "";

    String query = "SELECT id, datelb, lnamelb, fnamelb, mnamelb, genderlb, courselb, purposelb, timein_lb, timeout_lb, numberlb FROM loggbook WHERE delete_status = 0";

    try (Connection conn = DriverManager.getConnection(url, user, password);
         Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(query)) {

        DefaultTableModel model = new DefaultTableModel(
            new String[]{"ID", "Date", "Last Name", "First Name", "Middle Name", "Gender", "Course", "Purpose", "Time in", "Time Out", "Contact Number"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        while (rs.next()) {
            model.addRow(new Object[]{
                rs.getString("id"),
                rs.getString("datelb"),
                rs.getString("lnamelb"),
                rs.getString("fnamelb"),
                rs.getString("mnamelb"),
                rs.getString("genderlb"),
                rs.getString("courselb"),
                rs.getString("purposelb"),
                rs.getString("timein_lb"),
                rs.getString("timeout_lb"),
                rs.getString("numberlb")
            });
        }

        table.setModel(model);

        // Hide the ID column (index 0)
        table.getColumnModel().getColumn(0).setMinWidth(0);
        table.getColumnModel().getColumn(0).setMaxWidth(0);
        table.getColumnModel().getColumn(0).setWidth(0);

        // Auto-resize based on header and cell content
        autoResizeColumnWidths(table);

    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error fetching data from database.");
    }
}

   public static void resizeColumnWidths(JTable table) {
    final TableColumnModel columnModel = table.getColumnModel();
    for (int column = 0; column < table.getColumnCount(); column++) {
        int width = 50; // Min width
        TableCellRenderer headerRenderer = table.getTableHeader().getDefaultRenderer();
        Component headerComp = headerRenderer.getTableCellRendererComponent(table, table.getColumnName(column), false, false, 0, column);
        width = Math.max(width, headerComp.getPreferredSize().width);

        for (int row = 0; row < table.getRowCount(); row++) {
            TableCellRenderer cellRenderer = table.getCellRenderer(row, column);
            Component c = table.prepareRenderer(cellRenderer, row, column);
            width = Math.max(width, c.getPreferredSize().width);
        }

        columnModel.getColumn(column).setPreferredWidth(width + 23); // Add some padding
    }
}

   
   public static void autoResizeColumnWidths(JTable table) {
    final TableColumnModel columnModel = table.getColumnModel();
    for (int column = 1; column < table.getColumnCount(); column++) { // skip hidden ID column
        int width = 50; // min width
        TableColumn tableColumn = columnModel.getColumn(column);

        // Get header width
        TableCellRenderer headerRenderer = table.getTableHeader().getDefaultRenderer();
        Component headerComp = headerRenderer.getTableCellRendererComponent(
            table, tableColumn.getHeaderValue(), false, false, 0, column);
        width = Math.max(width, headerComp.getPreferredSize().width);

        // Get max cell content width
        for (int row = 0; row < table.getRowCount(); row++) {
            TableCellRenderer cellRenderer = table.getCellRenderer(row, column);
            Component cellComp = table.prepareRenderer(cellRenderer, row, column);
            width = Math.max(width, cellComp.getPreferredSize().width);
        }

        // Add margin
        width += 17;

        // Set the preferred width
        tableColumn.setPreferredWidth(width);
    }

    // Optional: Disable autoResizeMode so horizontal scroll can be used
    table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
}


        public static void fetchData4(JTable table) {
        String url = "jdbc:mysql://localhost:3306/logbook_db?zeroDateTimeBehavior=CONVERT_TO_NULL";
        String user = "root";
        String password = "";

        String query = "SELECT id, datelb, lnamelb, fnamelb, mnamelb, genderlb, courselb, purposelb, timein_lb, timeout_lb, numberlb FROM loggbook WHERE delete_status = 1";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            DefaultTableModel model = new DefaultTableModel(
                new String[]{"ID", "Date", "Last Name", "First Name", "Middle Name", "Gender", "Course", "Purpose", "Time in", "Time Out", "Contact Number"}, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };

            while (rs.next()) {
                String id = rs.getString("id");
                String date = rs.getString("datelb");
                String lastName = rs.getString("lnamelb");
                String firstName = rs.getString("fnamelb");
                String middleName = rs.getString("mnamelb");
                String gender = rs.getString("genderlb");
                String course = rs.getString("courselb");
                String purpose = rs.getString("purposelb");
                String timein = rs.getString("timein_lb");
                String timeout = rs.getString("timeout_lb");
                String cnum = rs.getString("numberlb");

                model.addRow(new Object[]{id, date, lastName, firstName, middleName, gender, course, purpose, timein, timeout, cnum});
            }

            table.setModel(model);

            // Hide the ID column (column index 0)
            table.getColumnModel().getColumn(0).setMinWidth(0);
            table.getColumnModel().getColumn(0).setMaxWidth(0);
            table.getColumnModel().getColumn(0).setWidth(0);

            // ===== Auto-resize column widths based on header text =====
            JTableHeader tableHeader = table.getTableHeader();
            TableColumnModel columnModel = table.getColumnModel();
            FontMetrics headerFontMetrics = tableHeader.getFontMetrics(tableHeader.getFont());

            for (int column = 1; column < table.getColumnCount(); column++) { // skip column 0
                String headerText = table.getColumnName(column);
                int headerWidth = headerFontMetrics.stringWidth(headerText) + 20; // add padding
                columnModel.getColumn(column).setPreferredWidth(headerWidth);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error fetching data from database.");
        }
    }

    public void updateUser(
        String student_id, String firstName, String lastName, String middleName,
        String course, String year, String address, String c_number, String g_number, JPanel qrtxt
    ) {
        try {
            // Check if the student_id exists
            String checkSql = "SELECT COUNT(*) FROM tbl_user WHERE student_id = ?";
            PreparedStatement checkStmt = conn.prepareStatement(checkSql);
            checkStmt.setString(1, student_id);
            ResultSet rs = checkStmt.executeQuery();

            if (!rs.next() || rs.getInt(1) == 0) {
                // Student ID does not exist
                JOptionPane.showMessageDialog(null, "Student ID not found. Cannot update non-existing record.");
                return;
            }

            // Generate QR Code
            String qrData = student_id + " | " + firstName + " | " + lastName + " | " + middleName + " | " + course +  " | " + year + " | " + address + " | " + c_number + " | " + g_number  ;
            BufferedImage qrImage = generateQRCodeImage(qrData);

//            // Display in panel
//            ImageIcon icon = new ImageIcon(qrImage);
//            JLabel qrLabel = new JLabel(icon);
//            qrtxt.removeAll();
//            qrtxt.add(qrLabel);
//            qrtxt.revalidate();
//            qrtxt.repaint();

            // Convert QR to byte[]
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ImageIO.write(qrImage, "png", baos);
            byte[] qrBytes = baos.toByteArray();

            // Update query
            String sql = "UPDATE tbl_user SET firstName = ?, lastName = ?, middleName = ?, course = ?, " +
                         "address = ?, c_number = ?, g_number = ?, qr_code = ?, gender =? WHERE student_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, firstName);
            pstmt.setString(2, lastName);
            pstmt.setString(3, middleName);
            pstmt.setString(4, course);
            pstmt.setString(5, address);
            pstmt.setString(6, c_number);
            pstmt.setString(7, g_number);
            pstmt.setBytes(8, qrBytes); // QR code as blob
            pstmt.setString(9, year);
            pstmt.setString(10, student_id); // WHERE condition

            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "User updated successfully with new QR Code!");
            } else {
                JOptionPane.showMessageDialog(null, "Update failed. Please try again.");
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error updating user.");
        }
    }
    
    public void deleteUser(String student_id) {
        int confirm = JOptionPane.showConfirmDialog(null,"Are you sure you want to permanently delete this user? This action cannot be undone.", 
        "Confirm Permanent Deletion", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                String sql = "DELETE FROM tbl_user WHERE student_id = ?";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, student_id);

                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(null, "User deleted successfully!");
                } else {
                    JOptionPane.showMessageDialog(null, "No user found with the given Student ID.");
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error deleting user.");
            }
        }
    }
    
        public void deleteUser3(String student_id) {
        int confirm = JOptionPane.showConfirmDialog(null,"Are you sure you want to permanently delete this user? This action cannot be undone.", 
        "Confirm Permanent Deletion", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                String sql = "DELETE FROM tbl_borrow WHERE id = ?";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, student_id);

                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(null, "User deleted successfully!");
                } else {
                    JOptionPane.showMessageDialog(null, "No user found with the given Student ID.");
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error deleting user.");
            }
        }
    }
    
    public void deleteUser1(String student_id) {
        int confirm = JOptionPane.showConfirmDialog(null,"Are you sure you want to permanently delete this user? This action cannot be undone.", 
        "Confirm Permanent Deletion", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                String sql = "DELETE FROM loggbook WHERE id = ?";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, student_id);

                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(null, "User deleted successfully!");
                } else {
                    JOptionPane.showMessageDialog(null, "No user found with the given Student ID.");
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error deleting user.");
            }
        }
    }


    
     // Method to fetch additional data (address, c_number, g_number) based on student_id
    public void fetchAdditionalData(String student_id) {
        String url = "jdbc:mysql://localhost:3306/logbook_db?zeroDateTimeBehavior=CONVERT_TO_NULL";
        String user = "root";
        String password = "";

        // Query to fetch additional fields for the selected student
        String query = "SELECT address, c_number, g_number FROM tbl_user WHERE student_id = ?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, student_id); // Set student_id in the query
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                String address = rs.getString("address");
                String c_number = rs.getString("c_number");
                String g_number = rs.getString("g_number");

                // Display in the JTextFields
                addresstxt.setText(address);
                cnumbertxt.setText(c_number);
                gnumbertxt.setText(g_number);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error fetching additional data.");
        }
    }

    
    
    public void generateqr() {
    String student_id = snumbertxt.getText().trim();
    String firstName = fnametxt.getText().trim();
    String lastName = lnametxt.getText().trim();
    String middleName = mnametxt.getText().trim();
    String course = (String) coursetxt.getSelectedItem();
    String year = (String) yeartxt.getSelectedItem();
    String address = addresstxt.getText().trim();
    String cnumber = cnumbertxt.getText().trim();
    String gnumber = gnumbertxt.getText().trim();

    // Check if all fields are filled and course/year are selected
    if (!student_id.isEmpty() && !firstName.isEmpty() && !lastName.isEmpty() &&
        !middleName.isEmpty() && !course.equalsIgnoreCase("select") && 
        !year.equalsIgnoreCase("select") && !address.isEmpty() &&
        !cnumber.isEmpty() && !gnumber.isEmpty()) {

        // Generate and display QR Code
        generateAndDisplayQRCode();
        qrtxt.setLayout(new FlowLayout());

    } else {
        // If any field is empty or unselected, clear QR panel
        qrtxt.removeAll();
        qrtxt.setLayout(new FlowLayout()); 
        qrtxt.setPreferredSize(new Dimension(qrtxt.getWidth(), 175));
        qrtxt.revalidate();
        qrtxt.repaint();
    }
}
    
    private void generateAndDisplayQRCode() {
    try {
        String student_id = snumbertxt.getText();
        String firstName = fnametxt.getText();
        String lastName = lnametxt.getText();
        String middleName = mnametxt.getText();
        String course = (String) coursetxt.getSelectedItem();
        String year = (String) yeartxt.getSelectedItem();
        String address = addresstxt.getText();
        String cnumber = cnumbertxt.getText();
        String gnumber = gnumbertxt.getText();

        // Only proceed if required fields for QR are filled
//        if (student_id.isEmpty() || firstName.isEmpty() || lastName.isEmpty()) {
//            JOptionPane.showMessageDialog(null, "Student ID, First Name, and Last Name are required to generate QR.");
//            return;
//        }

        String qrData = student_id + " | " + firstName + " | " + lastName + " | " + middleName + " | " + course +  " | " + year + " | " + address + " | " + cnumber + " | " + gnumber  ;
        BufferedImage qrImage = generateQRCodeImage(qrData);

        // Display in panel
        qrtxt.removeAll();
        JLabel qrLabel = new JLabel(new ImageIcon(qrImage));
        qrtxt.add(qrLabel);
        qrtxt.revalidate();
        qrtxt.repaint();
    } catch (Exception ex) {
        ex.printStackTrace();
    }
}

    

    public void insertUser(
        String student_id, String firstName, String lastName, String middleName,
        String course, String year, String address, String c_number, String g_number, JPanel qrtxt
    ) {
        try {
            
            // Check if the student_id already exists in the database
            String checkSql = "SELECT COUNT(*) FROM tbl_user WHERE student_id = ?";
            PreparedStatement checkStmt = conn.prepareStatement(checkSql);
            checkStmt.setString(1, student_id);
            ResultSet rs = checkStmt.executeQuery();

            if (rs.next() && rs.getInt(1) > 0) {
                // Student ID already exists
                JOptionPane.showMessageDialog(null, "This Student ID already exists. Please use a different ID.");
                return; // Exit the method without inserting
            }
        
            // Generate QR Code
            String qrData = student_id + " | " + firstName + " | " + lastName + " | " + middleName + " | " + course +  " | " + year + " | " + address + " | " + c_number + " | " + g_number  ;
            BufferedImage qrImage = generateQRCodeImage(qrData);

            // Show in Panel
            ImageIcon icon = new ImageIcon(qrImage);
            JLabel qrLabel = new JLabel(icon);

            // Ensure proper updating of panel content
            qrtxt.removeAll(); // Remove any existing QR codes
            qrtxt.add(qrLabel); // Add the new QR code label
            qrtxt.revalidate(); // Revalidate the panel to update its layout
            qrtxt.repaint(); // Repaint the panel to show the updated content

            // Convert QR to byte[] for database
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ImageIO.write(qrImage, "png", baos);
            byte[] qrBytes = baos.toByteArray();

            // Prepare SQL insert
            String sql = "INSERT INTO tbl_user (student_id, firstName, lastName, middleName, course, address, c_number, g_number, qr_code, gender) "
                       + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, student_id);
            pstmt.setString(2, firstName);
            pstmt.setString(3, lastName);
            pstmt.setString(4, middleName);
            pstmt.setString(5, course);
            pstmt.setString(6, address);
            pstmt.setString(7, c_number);
            pstmt.setString(8, g_number);
            pstmt.setBytes(9, qrBytes); // Store QR code as blob
            pstmt.setString(10, year);

            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "User inserted successfully with QR Code!");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private BufferedImage generateQRCodeImage(String data) throws WriterException {
    int width = 180;
    int height = 165;

    QRCodeWriter qrCodeWriter = new QRCodeWriter();

    // Add margin hint
    java.util.Map<EncodeHintType, Object> hints = new java.util.HashMap<>();
    hints.put(EncodeHintType.MARGIN, 1); // Default is 4; set 1 for thinner margin

    BitMatrix bitMatrix = qrCodeWriter.encode(data, BarcodeFormat.QR_CODE, width, height, hints);

    BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
    Graphics2D graphics = image.createGraphics();
    graphics.setColor(java.awt.Color.WHITE);
    graphics.fillRect(0, 0, width, height);
    graphics.setColor(java.awt.Color.BLACK);

    for (int x = 0; x < width; x++) {
        for (int y = 0; y < height; y++) {
            if (bitMatrix.get(x, y)) {
                graphics.fillRect(x, y, 1, 1);
            }
        }
    }

    return image;
}

    // Method to check if all fields are filled and generate QR code
    private void checkAndGenerateQRCode() {
        if (isAllFieldsFilled()) {
            insertUser(
                snumbertxt.getText(),
                fnametxt.getText(),
                lnametxt.getText(),
                mnametxt.getText(),
                (String)coursetxt.getSelectedItem(),
                (String)yeartxt.getSelectedItem(),
                addresstxt.getText(),
                cnumbertxt.getText(),
                gnumbertxt.getText(),
                qrtxt
            );
        }
    }

    // Check if all required fields are filled
    private boolean isAllFieldsFilled() {
        return !snumbertxt.getText().isEmpty() && !fnametxt.getText().isEmpty() &&
               !lnametxt.getText().isEmpty() && !mnametxt.getText().isEmpty() &&
               !((String) coursetxt.getSelectedItem()).isEmpty() && !addresstxt.getText().isEmpty() &&
               !cnumbertxt.getText().isEmpty() && !gnumbertxt.getText().isEmpty() &&
               !((String) yeartxt.getSelectedItem()).isEmpty()
;
    }
    
//private void initWebcam() {
//    Dimension size = WebcamResolution.QVGA.getSize();
//
//    if (Webcam.getWebcams().isEmpty()) {
//        JOptionPane.showMessageDialog(this, "No webcam detected.");
//        return;
//    }
//
//    webcam = Webcam.getWebcams().get(0);
//    webcam.setViewSize(size);
//
//    panel = new WebcamPanel(webcam);
//    panel.setPreferredSize(size);
//    panel.setFPSDisplayed(true);
//
//    qrtxt3.setLayout(new BorderLayout()); // ✅ Make sure layout is set
//    qrtxt3.add(panel, BorderLayout.CENTER); // ✅ Add ONLY to red panel
//    qrtxt3.revalidate();
//    qrtxt3.repaint();
//
//    executor.execute(this);
//}
    
        private void initWebcam1() {
        Dimension size = WebcamResolution.QVGA.getSize();

        if (Webcam.getWebcams().isEmpty()) {
            JOptionPane.showMessageDialog(this, "No webcam detected.");
            return;
        }

        webcam = Webcam.getWebcams().get(0);

        // Close webcam first if already open
        if (webcam.isOpen()) {
            webcam.close();
        }

        // Now it's safe to set the view size
        webcam.setViewSize(size);

        panel = new WebcamPanel(webcam);
        panel.setPreferredSize(size);
        panel.setFPSDisplayed(true);

        qrtxt4.setLayout(new BorderLayout());
        qrtxt4.add(panel, BorderLayout.CENTER);
        qrtxt4.revalidate();
        qrtxt4.repaint();

        executor.execute(this); // Start the thread that processes webcam frames
    }
        
    private void handleQRText1(String qrText) {
        try {
            // Remove whitespace and split by pipe
            String[] parts = qrText.split("\\s*\\|\\s*");

            if (parts.length < 9) {
                JOptionPane.showMessageDialog(null, "Wrong QR code. Please scan a valid one.");
                return;
            }
            
            testing.setText(parts[0].trim());
                        JOptionPane.showMessageDialog(null, "QR Code Scan Successully!");

                        String this_student_id = testing.getText(); // Input student ID
            String matchedStudentId = null;

            String selectSql = "SELECT student_id FROM loggbook " +
                               "WHERE student_id = ? AND timein_lb IS NOT NULL AND timeout_lb IS NULL " +
                               "ORDER BY id DESC LIMIT 1";

            try (PreparedStatement selectStmt = conn.prepareStatement(selectSql)) {
                selectStmt.setString(1, this_student_id); // filter by specific student ID
                ResultSet rs = selectStmt.executeQuery();

                if (rs.next()) {
                    matchedStudentId = rs.getString("student_id");

                    if (this_student_id.equals(matchedStudentId)) {


                                    // Assign each piece to your fields

                        snumbertxt.setText(parts[0].trim());
                        fnametxt.setText(parts[1].trim());      // First Name
                        lnametxt.setText(parts[2].trim());      // Last Name
                        mnametxt.setText(parts[3].trim());      // Middle Name
                        coursetxt.setSelectedItem(parts[4].trim());
                        yeartxt.setSelectedItem(parts[5].trim());  
                        addresstxt.setText(parts[6].trim());  
                        cnumbertxt.setText(parts[7].trim());      // Last Name
                        gnumbertxt.setText(parts[8].trim());

                        JOptionPane.showMessageDialog(null, "Please fill out the fileds!");
                        qrtxt4.removeAll();
                        qrtxt4.setLayout(new FlowLayout());
                        qrtxt4.setPreferredSize(new Dimension(qrtxt4.getWidth(), qrtxt4.getHeight()));

                        // Add scan component again
                        qrtxt4.add(scan);

                        // Ensure it's visible
                        scan.setVisible(false);

                        qrtxt4.revalidate();
                        qrtxt4.repaint();



                    } else {
                         JOptionPane.showMessageDialog(null, "Student ID found, but doesn't match input.", "", JOptionPane.INFORMATION_MESSAGE);
                    }

                } else {
                    JOptionPane.showMessageDialog(null, "This student didn't logbook.", "Log Status", JOptionPane.INFORMATION_MESSAGE);
            //        System.out.println("No active log (timein with no timeout) found for student_id: " + this_student_id);
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }
           

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error processing QR data.");
        }
}
   

    private void initWebcam() {
        Dimension size = WebcamResolution.QVGA.getSize();

        if (Webcam.getWebcams().isEmpty()) {
            JOptionPane.showMessageDialog(this, "No webcam detected.");
            return;
        }

        webcam = Webcam.getWebcams().get(0);

        // Close webcam first if already open
        if (webcam.isOpen()) {
            webcam.close();
        }

        // Now it's safe to set the view size
        webcam.setViewSize(size);

        panel = new WebcamPanel(webcam);
        panel.setPreferredSize(size);
        panel.setFPSDisplayed(true);

        qrtxt3.setLayout(new BorderLayout());
        qrtxt3.add(panel, BorderLayout.CENTER);
        qrtxt3.revalidate();
        qrtxt3.repaint();

        executor.execute(this); // Start the thread that processes webcam frames
    }
    
    @Override
    public void run() {
        do {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

//            BufferedImage image = null;

            if (webcam.isOpen()) {
                 BufferedImage image = webcam.getImage();
                if ((image = webcam.getImage()) == null) {
                    continue;
                }

                LuminanceSource source = new BufferedImageLuminanceSource(image);
                BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(source));

                try {
                    Result result = new MultiFormatReader().decode(bitmap);
                    lnametxt1.setText(result.getText());
                    String qrText = lnametxt1.getText();
                    String lb =  test.getText();
                    if("logbook".equals(lb)){
                        handleQRText(qrText);
                    }else if ("borrow".equals(lb)) {
                        handleQRText1(qrText);
                    }
                    
                    
                } catch (NotFoundException e) {
                    // no QR code in the image
                }
            }

        } while (true);
    }
    
    public void fetchStatus2() {
        String studentId = snumbertxt.getText().trim();

        String url = "jdbc:mysql://localhost:3306/logbook_db?zeroDateTimeBehavior=CONVERT_TO_NULL";
        String username = "root";
        String password = "";

        // Modified SQL: get the latest inserted log entry for the student
        String sql = "SELECT status, id, purposelb FROM loggbook WHERE student_id = ? ORDER BY id DESC LIMIT 1";

        try (Connection conn = DriverManager.getConnection(url, username, password);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, studentId);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int status = rs.getInt("status");
                    int myid = rs.getInt("id");
                    String purpose = rs.getString("purposelb");

                    purposetxt.setText(purpose);
                    stat.setText(String.valueOf(status));
                    idd.setText(String.valueOf(myid));
                } else {
                    stat.setText("Not Found");
                    purposetxt.setText("");
                    idd.setText("");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Database error occurred.");
        }
    }

    
    
    private void handleQRText(String qrText) {
    try {
                jPanel27.setPreferredSize(new Dimension(440, jPanel27.getHeight()));
                jPanel28.setPreferredSize(new Dimension(1061, jPanel28.getHeight()));
        // Remove whitespace and split by pipe
        String[] parts = qrText.split("\\s*\\|\\s*");

        if (parts.length < 9) {
             initWebcam();
            JOptionPane.showMessageDialog(null, "Wrong QR code. Please scan a valid one.");
            return;
        }


        // Assign each piece to your fields
        snumbertxt.setText(parts[0].trim());
        fnametxt.setText(parts[1].trim());      // First Name
        lnametxt.setText(parts[2].trim());      // Last Name
        mnametxt.setText(parts[3].trim());      // Middle Name
        coursetxt.setSelectedItem(parts[4].trim());
        yeartxt.setSelectedItem(parts[5].trim());  
        addresstxt.setText(parts[6].trim());  
        cnumbertxt.setText(parts[7].trim());      // Last Name
        gnumbertxt.setText(parts[8].trim());
       


        JOptionPane.showMessageDialog(null, "QR Code Scan Successully!!!");
        

        
        fetchStatus();
                String student_id = snumbertxt.getText();
        if ("1".equals(stat.getText())) {
            purposetxt.setEnabled(false);
            fetchStatus2();
            updateStatus(conn, student_id);
            
        } else  {
            JOptionPane.showMessageDialog(null, "Please Eneter your purpose!");
            purposetxt.setEnabled(true);
            purposetxt.setText("");
            
            qrtxt3.removeAll();
            qrtxt3.setLayout(new FlowLayout());
            qrtxt3.setPreferredSize(new Dimension(qrtxt3.getWidth(), qrtxt3.getHeight()));
           
            // Add scan component again
            qrtxt3.add(scan);

            // Ensure it's visible
            scan.setVisible(false);

            qrtxt3.revalidate();
            qrtxt3.repaint();
        }



    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error processing QR data.");
    }
}


    @Override
    public Thread newThread(Runnable r) {
        Thread t = new Thread(r, "QRScannerThread");
        t.setDaemon(true);
        return t;
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new dashboard(0).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField addresstxt;
    private javax.swing.JTextField author;
    private javax.swing.JTextField booknum;
    private javax.swing.JTextField booktitle;
    private javax.swing.JTextField cnumbertxt;
    private javax.swing.JComboBox<String> courselb1;
    private javax.swing.JComboBox<String> courselb2;
    private javax.swing.JComboBox<String> courselb3;
    private javax.swing.JComboBox<String> coursetxt;
    private javax.swing.JTextField fnametxt;
    private com.toedter.calendar.JDateChooser fromDateChooser;
    private com.toedter.calendar.JDateChooser fromDateChooser1;
    private com.toedter.calendar.JDateChooser fromDateChooser2;
    private javax.swing.JTextField gnumbertxt;
    private javax.swing.JLabel icon;
    private javax.swing.JLabel icon1;
    private javax.swing.JLabel id10;
    private javax.swing.JTextField id12;
    private javax.swing.JLabel idd;
    private javax.swing.JLabel idd1;
    private javax.swing.JLabel idddd;
    private javax.swing.JLabel isd2;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton20;
    private javax.swing.JButton jButton21;
    private javax.swing.JButton jButton22;
    private javax.swing.JButton jButton23;
    private javax.swing.JButton jButton24;
    private javax.swing.JButton jButton25;
    private javax.swing.JButton jButton26;
    private javax.swing.JButton jButton27;
    private javax.swing.JButton jButton28;
    private javax.swing.JButton jButton29;
    private javax.swing.JButton jButton30;
    private javax.swing.JButton jButton31;
    private javax.swing.JButton jButton32;
    private javax.swing.JButton jButton33;
    private javax.swing.JButton jButton34;
    private javax.swing.JButton jButton35;
    private javax.swing.JButton jButton36;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel33;
    private javax.swing.JPanel jPanel34;
    private javax.swing.JPanel jPanel35;
    private javax.swing.JPanel jPanel36;
    private javax.swing.JPanel jPanel37;
    private javax.swing.JPanel jPanel38;
    private javax.swing.JPanel jPanel39;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel40;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTable jTable4;
    private javax.swing.JTable jTable5;
    private javax.swing.JTable jTable6;
    private javax.swing.JTable jTable7;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField lnametxt;
    private javax.swing.JTextField lnametxt1;
    private javax.swing.JTextField lnametxt2;
    private javax.swing.JTextField mnametxt;
    private javax.swing.JTextField myid;
    private javax.swing.JComboBox<String> purposecb;
    private javax.swing.JTextField purposetxt;
    private javax.swing.JPanel qrtxt;
    private javax.swing.JPanel qrtxt3;
    private javax.swing.JPanel qrtxt4;
    private javax.swing.JButton scan;
    private javax.swing.JTextField search;
    private javax.swing.JTextField search1;
    private javax.swing.JTextField search3;
    private javax.swing.JTextField searchtxt;
    private javax.swing.JTextField searchtxt1;
    private javax.swing.JTextField searchtxt2;
    private javax.swing.JLabel sid;
    private javax.swing.JLabel sid1;
    private javax.swing.JLabel sid2;
    private javax.swing.JTextField snumbertxt;
    private javax.swing.JTextField stat;
    private javax.swing.JTextField test;
    private javax.swing.JTextField testing;
    private com.toedter.calendar.JDateChooser toDateChoose1;
    private com.toedter.calendar.JDateChooser toDateChooser;
    private com.toedter.calendar.JDateChooser toDateChooser1;
    private javax.swing.JLabel usernametxt;
    private javax.swing.JLabel usernametxt10;
    private javax.swing.JLabel usernametxt2;
    private javax.swing.JLabel usernametxt3;
    private javax.swing.JLabel usernametxt4;
    private javax.swing.JLabel usernametxt8;
    private javax.swing.JLabel usernametxt9;
    private javax.swing.JComboBox<String> yeartxt;
    // End of variables declaration//GEN-END:variables
}
